---
name: dmtt-maceio-design
description: Use this skill to generate well-branded interfaces and assets for Linhas DMTT — the bus-itinerary MicroSaaS of the GEPOT/DMTT sector in Maceió/AL — either for production or throwaway prototypes/mocks. Clean light theme, gold accent from the Policiamento Viário badge, realistic shadows, minimalist. Contains design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the `readme.md` file within this skill first, then explore the other available files.

- **Foundations** live in `styles.css` + `tokens/` (colors, typography, spacing, fonts, base). Link `styles.css` to inherit every token.
- **Components** live in `components/<group>/` as React `.jsx` with `.d.ts` + `.prompt.md`. Read the `.prompt.md` for usage. They style themselves via CSS custom properties and are exported under `window.DMTTMaceiDesignSystem_aa209f`.
- **Product recreations** live in `ui_kits/dmtt/` — the interactive Linhas / Dashboards / Sobre app.
- **Brand asset:** `assets/logo-policiamento-viario.png`.

If creating visual artifacts (slides, mocks, throwaway prototypes), copy assets out and create static HTML files for the user to view. If working on production code, copy assets and follow the rules here to become an expert in designing with this brand.

Key rules: Brazilian-Portuguese UI copy; clean light theme — gold `#E4B21E` accent (readable gold text `#7E5C09`) on white / soft-gray surfaces with realistic layered shadows; **IDA green / VOLTA blue are functional route colors — never recolor them**; no emoji (use Unicode glyphs `→ ← ✓ ~ ?`); single-family IBM Plex Sans + IBM Plex Mono.

If the user invokes this skill without other guidance, ask them what they want to build, ask a few questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.
