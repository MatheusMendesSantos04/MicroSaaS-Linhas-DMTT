/* @ds-bundle: {"format":4,"namespace":"DMTTMaceiDesignSystem_aa209f","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"MultiSelect","sourcePath":"components/forms/MultiSelect.jsx"},{"name":"OptionButton","sourcePath":"components/forms/OptionButton.jsx"},{"name":"SearchInput","sourcePath":"components/forms/SearchInput.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"NavBar","sourcePath":"components/navigation/NavBar.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"ItineraryRow","sourcePath":"components/transit/ItineraryRow.jsx"},{"name":"MatchMark","sourcePath":"components/transit/MatchMark.jsx"},{"name":"RouteBadge","sourcePath":"components/transit/RouteBadge.jsx"},{"name":"SidebarPanel","sourcePath":"components/transit/SidebarPanel.jsx"},{"name":"TimeChip","sourcePath":"components/transit/TimeChip.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"727aa30a9da1","components/core/Button.jsx":"1707a38251aa","components/core/Card.jsx":"94a3521e461b","components/forms/MultiSelect.jsx":"67c70b9db758","components/forms/OptionButton.jsx":"a0a8fda88076","components/forms/SearchInput.jsx":"744e6432f2f3","components/forms/Select.jsx":"6d3dcd9e6787","components/navigation/NavBar.jsx":"cffc0abd21b7","components/navigation/Tabs.jsx":"c030fb0afb3d","components/transit/ItineraryRow.jsx":"ad936e593c63","components/transit/MatchMark.jsx":"e56b6f6bc3aa","components/transit/RouteBadge.jsx":"50799654548b","components/transit/SidebarPanel.jsx":"d4c191024ac0","components/transit/TimeChip.jsx":"bb399430790d","ui_kits/dmtt/DashboardsScreen.jsx":"e0522c40836e","ui_kits/dmtt/LinhasScreen.jsx":"880087559835","ui_kits/dmtt/MapCanvas.jsx":"7e237e7ed0c8","ui_kits/dmtt/SobreScreen.jsx":"950ecfe8440a"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.DMTTMaceiDesignSystem_aa209f = window.DMTTMaceiDesignSystem_aa209f || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Badge — small status pill. Used for dashboard access type (Público / Interno),
 * loading / error states, and generic labels.
 */
function Badge({
  children,
  tone = "neutral",
  size = "md",
  style = {},
  ...rest
}) {
  const tones = {
    neutral: {
      background: "var(--surface-base)",
      color: "var(--text-subtle)",
      border: "1px solid var(--border-2)"
    },
    gold: {
      background: "rgba(228,178,30,0.14)",
      color: "var(--gold-700)",
      border: "1px solid rgba(228,178,30,0.42)"
    },
    success: {
      background: "var(--success-soft)",
      color: "var(--success-text)",
      border: "1px solid rgba(22,163,74,0.30)"
    },
    warning: {
      background: "var(--warning-soft)",
      color: "var(--warning-text)",
      border: "1px solid rgba(217,132,7,0.32)"
    },
    danger: {
      background: "var(--danger-soft)",
      color: "var(--danger-text)",
      border: "1px solid rgba(220,38,38,0.28)"
    },
    info: {
      background: "var(--info-soft)",
      color: "#1E4FB0",
      border: "1px solid rgba(46,100,212,0.30)"
    }
  };
  const sizes = {
    sm: {
      padding: "1px 6px",
      fontSize: "var(--fs-2xs)"
    },
    md: {
      padding: "2px 8px",
      fontSize: "var(--fs-2xs)"
    }
  };
  const t = tones[tone] || tones.neutral;
  const s = sizes[size] || sizes.md;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 4,
      fontFamily: "var(--font-sans)",
      fontWeight: "var(--fw-bold)",
      textTransform: "uppercase",
      letterSpacing: "var(--ls-wide)",
      lineHeight: 1.4,
      borderRadius: "var(--radius-sm)",
      whiteSpace: "nowrap",
      ...t,
      ...s,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Button — primary action control for the DMTT interface.
 * Gold primary on dark; compact by default (this is a dense operational tool).
 */
function Button({
  children,
  variant = "primary",
  size = "md",
  disabled = false,
  fullWidth = false,
  iconLeft = null,
  iconRight = null,
  type = "button",
  onClick,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: {
      padding: "5px 10px",
      fontSize: "var(--fs-xs)",
      height: 28,
      gap: 6
    },
    md: {
      padding: "8px 16px",
      fontSize: "var(--fs-sm)",
      height: 36,
      gap: 8
    },
    lg: {
      padding: "11px 22px",
      fontSize: "var(--fs-body)",
      height: 44,
      gap: 8
    }
  };
  const variants = {
    primary: {
      background: "var(--primary)",
      color: "var(--on-primary)",
      border: "1px solid transparent",
      fontWeight: "var(--fw-bold)"
    },
    secondary: {
      background: "var(--surface-input)",
      color: "var(--text-body)",
      border: "1px solid var(--border-2)",
      fontWeight: "var(--fw-semibold)"
    },
    ghost: {
      background: "transparent",
      color: "var(--text-subtle)",
      border: "1px solid transparent",
      fontWeight: "var(--fw-semibold)"
    },
    danger: {
      background: "var(--danger-soft)",
      color: "var(--danger-text)",
      border: "1px solid rgba(242,96,96,0.35)",
      fontWeight: "var(--fw-semibold)"
    }
  };
  const s = sizes[size] || sizes.md;
  const v = variants[variant] || variants.primary;
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const hoverStyle = !disabled && hover ? variant === "primary" ? {
    background: "var(--primary-hover)"
  } : variant === "ghost" ? {
    background: "var(--surface-hover)",
    color: "var(--text-body)"
  } : {
    borderColor: "var(--border-3)",
    background: "var(--surface-hover)"
  } : {};
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setActive(false);
    },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false),
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      gap: s.gap,
      width: fullWidth ? "100%" : "auto",
      height: s.height,
      padding: s.padding,
      fontFamily: "var(--font-sans)",
      fontSize: s.fontSize,
      lineHeight: 1,
      letterSpacing: "0.01em",
      borderRadius: "var(--radius)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.45 : 1,
      transform: active && !disabled ? "translateY(1px)" : "none",
      transition: "background var(--dur-fast) var(--ease-std), border-color var(--dur-fast), transform var(--dur-fast), color var(--dur-fast)",
      whiteSpace: "nowrap",
      ...v,
      ...hoverStyle,
      ...style
    }
  }, rest), iconLeft, children, iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Card — raised surface container. `interactive` adds gold hover border + lift,
 * used for the Dashboards grid (each card is a link to a Power BI report).
 */
function Card({
  children,
  interactive = false,
  as = "div",
  padding = "var(--sp-6)",
  style = {},
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const Tag = as;
  return /*#__PURE__*/React.createElement(Tag, _extends({
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--sp-4)",
      padding,
      background: "var(--surface-card)",
      border: "1px solid var(--border-card)",
      borderRadius: "var(--radius-md)",
      color: "var(--text-body)",
      textDecoration: "none",
      boxShadow: "var(--shadow-sm)",
      transition: "border-color var(--dur) var(--ease-std), box-shadow var(--dur), transform var(--dur)",
      ...(interactive && hover ? {
        borderColor: "rgba(228,178,30,0.55)",
        boxShadow: "var(--shadow-md)",
        transform: "translateY(-2px)",
        cursor: "pointer"
      } : {}),
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/forms/MultiSelect.jsx
try { (() => {
/**
 * MultiSelect — searchable checkbox dropdown. The line selector on the map view:
 * pick one line to see its full itinerary, or several to overlay their routes.
 * `options` is [{ id, label }]. Controlled via `selectedIds` + `onToggle`.
 */
function MultiSelect({
  options = [],
  selectedIds = [],
  onToggle,
  onClear,
  placeholder = "Todas as linhas",
  panelWidth = 460,
  style = {}
}) {
  const [open, setOpen] = React.useState(false);
  const [search, setSearch] = React.useState("");
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!open) return;
    function h(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, [open]);
  const filtered = search.trim() ? options.filter(o => o.label.toLowerCase().includes(search.toLowerCase())) : options;
  const label = selectedIds.length === 0 ? placeholder : selectedIds.length === 1 ? options.find(o => o.id === selectedIds[0])?.label ?? "1 selecionada" : `${selectedIds.length} linhas selecionadas`;
  return /*#__PURE__*/React.createElement("div", {
    ref: ref,
    style: {
      position: "relative",
      display: "inline-flex",
      alignItems: "center",
      gap: 4,
      ...style
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setOpen(v => !v),
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      minWidth: 260,
      height: 34,
      padding: "0 10px",
      textAlign: "left",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--fs-sm)",
      color: "var(--text-body)",
      background: "var(--surface-input)",
      border: `1px solid ${open ? "var(--focus-ring)" : "var(--border-input)"}`,
      boxShadow: open ? "var(--shadow-focus)" : "none",
      borderRadius: "var(--radius)",
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 8,
      color: "var(--text-hint)"
    }
  }, open ? "▲" : "▼")), selectedIds.length > 0 && /*#__PURE__*/React.createElement("button", {
    onClick: () => {
      onClear && onClear();
      setSearch("");
    },
    title: "Limpar sele\xE7\xE3o",
    style: {
      width: 24,
      height: 24,
      flexShrink: 0,
      border: "none",
      borderRadius: "50%",
      background: "var(--ink-500)",
      color: "var(--text-subtle)",
      fontSize: 11,
      cursor: "pointer",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, "\u2715"), open && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: "calc(100% + 6px)",
      left: 0,
      zIndex: 3000,
      width: panelWidth,
      maxHeight: 340,
      display: "flex",
      flexDirection: "column",
      background: "var(--surface-card)",
      border: "1px solid var(--border-3)",
      borderRadius: "var(--radius-md)",
      boxShadow: "var(--shadow-pop)",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      padding: 8,
      borderBottom: "1px solid var(--border-1)"
    }
  }, /*#__PURE__*/React.createElement("input", {
    autoFocus: true,
    value: search,
    onChange: e => setSearch(e.target.value),
    placeholder: "Filtrar linha\u2026",
    style: {
      flex: 1,
      height: 30,
      padding: "0 8px",
      background: "var(--surface-input)",
      border: "1px solid var(--border-2)",
      borderRadius: "var(--radius)",
      color: "var(--text-body)",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--fs-sm)",
      outline: "none"
    }
  }), selectedIds.length > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--fs-2xs)",
      fontWeight: "var(--fw-bold)",
      color: "var(--on-primary)",
      background: "var(--primary)",
      borderRadius: 999,
      padding: "2px 8px",
      whiteSpace: "nowrap"
    }
  }, selectedIds.length, " \u2713")), /*#__PURE__*/React.createElement("div", {
    style: {
      overflowY: "auto",
      flex: 1
    }
  }, filtered.length === 0 && /*#__PURE__*/React.createElement("p", {
    style: {
      padding: 12,
      fontSize: "var(--fs-sm)",
      color: "var(--text-hint)"
    }
  }, "Nenhuma linha encontrada"), filtered.map(o => {
    const checked = selectedIds.includes(o.id);
    return /*#__PURE__*/React.createElement("label", {
      key: o.id,
      style: {
        display: "flex",
        alignItems: "center",
        gap: 9,
        padding: "8px 12px",
        cursor: "pointer",
        fontSize: "var(--fs-sm)",
        color: "var(--text-body)",
        borderBottom: "1px solid var(--border-1)",
        background: checked ? "rgba(233,183,41,0.10)" : "transparent",
        userSelect: "none"
      }
    }, /*#__PURE__*/React.createElement("input", {
      type: "checkbox",
      checked: checked,
      onChange: () => onToggle && onToggle(o.id),
      style: {
        width: 15,
        height: 15,
        accentColor: "var(--primary)",
        cursor: "pointer"
      }
    }), /*#__PURE__*/React.createElement("span", null, o.label));
  }))));
}
Object.assign(__ds_scope, { MultiSelect });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/MultiSelect.jsx", error: String((e && e.message) || e) }); }

// components/forms/OptionButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * OptionButton — full-width selectable list row with a leading swatch/icon and
 * an active state. Used for map-style choices and the Terminais toggle.
 * `accent` recolors the active + hover state (gold by default; orange for Terminais).
 */
function OptionButton({
  children,
  active = false,
  swatch = null,
  accent = "var(--primary)",
  accentSoft = "rgba(233,183,41,0.14)",
  onClick,
  style = {},
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", _extends({
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      width: "100%",
      padding: "8px 10px",
      textAlign: "left",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--fs-sm)",
      fontWeight: active ? "var(--fw-semibold)" : "var(--fw-regular)",
      color: active ? accent : "var(--text-body)",
      background: active ? accentSoft : hover ? "var(--surface-hover)" : "var(--surface-input)",
      border: `1px solid ${active || hover ? accent : "var(--border-2)"}`,
      borderRadius: "var(--radius)",
      cursor: "pointer",
      transition: "border-color var(--dur-fast), background var(--dur-fast), color var(--dur-fast)",
      ...style
    }
  }, rest), swatch, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, children), active && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: "var(--fw-bold)",
      color: accent
    }
  }, "\u2713"));
}
Object.assign(__ds_scope, { OptionButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/OptionButton.jsx", error: String((e && e.message) || e) }); }

// components/forms/SearchInput.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SearchInput — text field with optional leading icon and trailing spinner.
 * Used for the street search (autocomplete) and the line filter.
 */
function SearchInput({
  value,
  onChange,
  placeholder = "",
  icon = null,
  loading = false,
  size = "md",
  fullWidth = true,
  style = {},
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const sizes = {
    sm: {
      height: 32,
      fontSize: "var(--fs-sm)",
      pad: 8
    },
    md: {
      height: 38,
      fontSize: "var(--fs-sm)",
      pad: 10
    }
  };
  const s = sizes[size] || sizes.md;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      width: fullWidth ? "100%" : "auto",
      height: s.height,
      padding: `0 ${s.pad}px`,
      background: "var(--surface-input)",
      border: `1px solid ${focus ? "var(--focus-ring)" : "var(--border-input)"}`,
      borderRadius: "var(--radius)",
      boxShadow: focus ? "var(--shadow-focus)" : "none",
      transition: "border-color var(--dur-fast), box-shadow var(--dur-fast)",
      ...style
    }
  }, icon && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      color: "var(--text-hint)",
      flexShrink: 0
    }
  }, icon), /*#__PURE__*/React.createElement("input", _extends({
    value: value,
    onChange: onChange,
    placeholder: placeholder,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    autoComplete: "off",
    style: {
      flex: 1,
      minWidth: 0,
      background: "transparent",
      border: "none",
      outline: "none",
      color: "var(--text-body)",
      fontFamily: "var(--font-sans)",
      fontSize: s.fontSize
    }
  }, rest)), loading && /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--text-hint)",
      fontSize: 13,
      flexShrink: 0
    }
  }, "\u2026"));
}
Object.assign(__ds_scope, { SearchInput });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/SearchInput.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Select — styled native select for the dark theme (Sentido, Dia, etc.).
 * Wrap with a label externally, or pass `label` for an inline eyebrow.
 */
function Select({
  value,
  onChange,
  children,
  label = null,
  size = "md",
  style = {},
  ...rest
}) {
  const sizes = {
    sm: {
      padding: "5px 26px 5px 8px",
      fontSize: "var(--fs-xs)",
      height: 30
    },
    md: {
      padding: "7px 30px 7px 10px",
      fontSize: "var(--fs-sm)",
      height: 34
    }
  };
  const s = sizes[size] || sizes.md;
  const select = /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      display: "inline-flex",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    value: value,
    onChange: onChange,
    style: {
      appearance: "none",
      WebkitAppearance: "none",
      fontFamily: "var(--font-sans)",
      color: "var(--text-body)",
      background: "var(--surface-input)",
      border: "1px solid var(--border-input)",
      borderRadius: "var(--radius)",
      cursor: "pointer",
      outline: "none",
      ...s,
      ...style
    }
  }, rest), children), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": true,
    style: {
      position: "absolute",
      right: 10,
      pointerEvents: "none",
      fontSize: 9,
      color: "var(--text-hint)"
    }
  }, "\u25BC"));
  if (!label) return select;
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--sp-4)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--fs-xs)",
      fontWeight: "var(--fw-semibold)",
      color: "var(--text-subtle)",
      whiteSpace: "nowrap"
    }
  }, label), select);
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/navigation/NavBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * NavBar — top application bar. Badge mark + wordmark on the left, nav links
 * on the right. Links: [{ label, href, active }].
 */
function NavBar({
  brand = "Linhas DMTT",
  subtitle = "Maceió",
  logoSrc = null,
  links = [],
  style = {}
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--sp-8)",
      height: "var(--topbar-h)",
      padding: "0 var(--sp-6)",
      background: "var(--surface-topbar)",
      borderBottom: "1px solid var(--border-2)",
      flexShrink: 0,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      minWidth: 0
    }
  }, logoSrc && /*#__PURE__*/React.createElement("img", {
    src: logoSrc,
    alt: "",
    style: {
      height: 36,
      width: "auto",
      display: "block",
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      lineHeight: 1.05,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: "var(--fw-bold)",
      fontSize: 18,
      letterSpacing: "0.01em",
      color: "var(--text-1)",
      whiteSpace: "nowrap"
    }
  }, brand), subtitle && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--fs-2xs)",
      fontWeight: "var(--fw-semibold)",
      letterSpacing: "var(--ls-caps)",
      textTransform: "uppercase",
      color: "var(--gold-600)"
    }
  }, subtitle))), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      gap: 4,
      marginLeft: "auto"
    }
  }, links.map(l => /*#__PURE__*/React.createElement(NavLink, _extends({
    key: l.label
  }, l)))));
}
function NavLink({
  label,
  href = "#",
  active = false,
  onClick
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("a", {
    href: href,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      padding: "7px 13px",
      borderRadius: "var(--radius)",
      fontSize: "var(--fs-sm)",
      fontWeight: "var(--fw-semibold)",
      textDecoration: "none",
      color: active ? "var(--text-1)" : hover ? "var(--text-1)" : "var(--text-3)",
      background: active ? "rgba(228,178,30,0.16)" : hover ? "var(--surface-hover)" : "transparent",
      boxShadow: active ? "inset 0 -2px 0 var(--gold-400)" : "none",
      transition: "background var(--dur-fast), color var(--dur-fast)"
    }
  }, label);
}
Object.assign(__ds_scope, { NavBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/NavBar.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
/**
 * Tabs — segmented control that connects to the panel body below it (the
 * horários day switcher: Dia Útil / Sábado / Domingo).
 * `items` = [{ key, label }]. Controlled via `value` + `onChange`.
 */
function Tabs({
  items = [],
  value,
  onChange,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 4,
      ...style
    }
  }, items.map(it => {
    const active = it.key === value;
    return /*#__PURE__*/React.createElement("button", {
      key: it.key,
      onClick: () => onChange && onChange(it.key),
      style: {
        flex: 1,
        padding: "6px 4px",
        fontFamily: "var(--font-sans)",
        fontSize: "var(--fs-xs)",
        fontWeight: "var(--fw-semibold)",
        color: active ? "var(--gold-700)" : "var(--text-3)",
        background: active ? "var(--surface-card)" : "var(--surface-input)",
        border: "1px solid var(--border-2)",
        borderBottom: active ? "1px solid var(--surface-card)" : "1px solid var(--border-2)",
        borderRadius: "var(--radius) var(--radius) 0 0",
        cursor: "pointer",
        position: "relative",
        marginBottom: -1,
        zIndex: active ? 1 : 0,
        transition: "color var(--dur-fast), background var(--dur-fast)"
      }
    }, it.label);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/transit/MatchMark.jsx
try { (() => {
/**
 * MatchMark — itinerary code-match indicator. exact ✓ (green), fuzzy ~ (amber),
 * none ? (muted). Signals how confidently a street was matched to an official code.
 */
function MatchMark({
  match = "exato",
  style = {}
}) {
  const MAP = {
    exato: {
      label: "✓",
      color: "var(--success)",
      title: "Match exato"
    },
    exato_global: {
      label: "✓",
      color: "var(--success)",
      title: "Match exato (global)"
    },
    fuzzy: {
      label: "~",
      color: "var(--warning)",
      title: "Match aproximado"
    },
    fuzzy_global: {
      label: "~",
      color: "var(--warning)",
      title: "Match aproximado (global)"
    },
    contem: {
      label: "~",
      color: "var(--warning)",
      title: "Match por contenção"
    },
    exato_sem_complemento: {
      label: "~",
      color: "var(--warning)",
      title: "Match sem complemento"
    },
    nao_encontrado: {
      label: "?",
      color: "var(--text-4)",
      title: "Código não encontrado"
    }
  };
  const m = MAP[match] || MAP.nao_encontrado;
  return /*#__PURE__*/React.createElement("span", {
    title: m.title,
    style: {
      display: "inline-block",
      width: 16,
      textAlign: "center",
      flexShrink: 0,
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      fontWeight: "var(--fw-bold)",
      color: m.color,
      ...style
    }
  }, m.label);
}
Object.assign(__ds_scope, { MatchMark });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/transit/MatchMark.jsx", error: String((e && e.message) || e) }); }

// components/transit/RouteBadge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * RouteBadge — direction (sentido) badge. IDA = green, VOLTA = blue,
 * matching the route colors drawn on the map. Optional mono code suffix.
 * Pass `onClick` to make it an interactive filter chip.
 */
function RouteBadge({
  sentido = "ida",
  code = null,
  onClick,
  style = {},
  ...rest
}) {
  const isIda = sentido === "ida";
  const bg = isIda ? "var(--ida)" : "var(--volta)";
  const label = isIda ? "→ IDA" : "← VOLTA";
  const [hover, setHover] = React.useState(false);
  const clickable = !!onClick;
  return /*#__PURE__*/React.createElement("span", _extends({
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 5,
      padding: "3px 9px",
      fontSize: "var(--fs-2xs)",
      fontWeight: "var(--fw-bold)",
      letterSpacing: "0.02em",
      color: "#08130B",
      background: bg,
      borderRadius: "var(--radius-sm)",
      cursor: clickable ? "pointer" : "default",
      filter: clickable && hover ? "brightness(1.1)" : "none",
      transform: clickable && hover ? "scale(1.04)" : "none",
      transition: "filter var(--dur-fast), transform var(--dur-fast)",
      whiteSpace: "nowrap",
      ...style
    }
  }, rest), label, code && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 10,
      opacity: 0.72,
      fontWeight: 500
    }
  }, code));
}
Object.assign(__ds_scope, { RouteBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/transit/RouteBadge.jsx", error: String((e && e.message) || e) }); }

// components/transit/SidebarPanel.jsx
try { (() => {
/**
 * SidebarPanel — titled section block for the map sidebar. Uppercase eyebrow
 * title + arbitrary body. `hint` renders a muted empty-state line instead of children.
 */
function SidebarPanel({
  title,
  hint = null,
  children,
  divider = true,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      borderBottom: divider ? "1px solid var(--border-2)" : "none",
      ...style
    }
  }, title && /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--fs-xs)",
      fontWeight: "var(--fw-bold)",
      textTransform: "uppercase",
      letterSpacing: "var(--ls-caps)",
      color: "var(--text-subtle)",
      padding: "14px 16px 8px",
      borderBottom: "1px solid var(--border-1)"
    }
  }, title), hint ? /*#__PURE__*/React.createElement("p", {
    style: {
      padding: "12px 16px",
      fontSize: "var(--fs-sm)",
      color: "var(--text-hint)"
    }
  }, hint) : children);
}
Object.assign(__ds_scope, { SidebarPanel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/transit/SidebarPanel.jsx", error: String((e && e.message) || e) }); }

// components/transit/TimeChip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * TimeChip — a single departure time (monospace). `highlight` marks times inside
 * the ±20 min search window; `variant="code"` renders an inline street/line code.
 */
function TimeChip({
  children,
  highlight = false,
  variant = "time",
  style = {},
  ...rest
}) {
  if (variant === "code") {
    return /*#__PURE__*/React.createElement("span", _extends({
      style: {
        fontFamily: "var(--font-mono)",
        fontSize: 10,
        color: "var(--text-hint)",
        background: "var(--ink-600)",
        borderRadius: "var(--radius-xs)",
        padding: "1px 5px",
        whiteSpace: "nowrap",
        ...style
      }
    }, rest), children);
  }
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--fs-xs)",
      fontWeight: "var(--fw-semibold)",
      padding: "2px 8px",
      borderRadius: "var(--radius-sm)",
      color: highlight ? "var(--gold-100)" : "var(--text-body)",
      background: highlight ? "rgba(233,183,41,0.16)" : "var(--ink-600)",
      border: `1px solid ${highlight ? "rgba(233,183,41,0.45)" : "var(--border-2)"}`,
      whiteSpace: "nowrap",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { TimeChip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/transit/TimeChip.jsx", error: String((e && e.message) || e) }); }

// components/transit/ItineraryRow.jsx
try { (() => {
/**
 * ItineraryRow — one street in a line's itinerary: match mark + street name +
 * optional official code. Rows stack inside a SidebarPanel section.
 */
function ItineraryRow({
  via,
  match = "exato",
  codigo = null,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("li", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      padding: "6px 16px",
      fontSize: "var(--fs-sm)",
      color: "var(--text-body)",
      borderBottom: "1px solid var(--border-1)",
      listStyle: "none",
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.MatchMark, {
    match: match
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, via), codigo && /*#__PURE__*/React.createElement(__ds_scope.TimeChip, {
    variant: "code"
  }, codigo));
}
Object.assign(__ds_scope, { ItineraryRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/transit/ItineraryRow.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dmtt/DashboardsScreen.jsx
try { (() => {
// DashboardsScreen — GEPOT Power BI dashboards grid. Público vs Interno via Badge tone.
const DSb = window.DMTTMaceiDesignSystem_aa209f;
const DASHBOARDS = [{
  titulo: "Frota e Quilometragem",
  descricao: "Acompanhamento mensal de quilometragem rodada por linha e por motorista.",
  tipo: "interno"
}, {
  titulo: "Itinerários e Pontos de Parada",
  descricao: "Visão consolidada de linhas, ruas atendidas e pontos de parada por bairro.",
  tipo: "publico"
}, {
  titulo: "Indicadores Mensais GEPOT",
  descricao: "Painel de indicadores do setor: relatórios entregues, prazos e pendências.",
  tipo: "interno"
}, {
  titulo: "Reclamações por Bairro",
  descricao: "Mapa de calor das reclamações recebidas, cruzado com linhas que atendem cada bairro.",
  tipo: "publico"
}];
function DashboardsScreen() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      overflowY: "auto",
      padding: "32px 36px 56px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 900
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: 26,
      color: "var(--text-1)",
      marginBottom: 6
    }
  }, "Dashboards \u2014 GEPOT"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 14,
      color: "var(--text-subtle)",
      marginBottom: 28,
      maxWidth: 620,
      lineHeight: 1.55
    }
  }, "Relat\xF3rios e indicadores do setor, publicados no Power BI. Atualiza\xE7\xE3o manual \u2014 a raspagem pesada roda sexta, o ", /*#__PURE__*/React.createElement("code", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 12,
      color: "var(--gold-700)"
    }
  }, ".pbix"), " \xE9 republicado segunda. Os links abaixo n\xE3o mudam, s\xF3 o conte\xFAdo por tr\xE1s."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))",
      gap: 16
    }
  }, DASHBOARDS.map(d => /*#__PURE__*/React.createElement(DSb.Card, {
    key: d.titulo,
    interactive: true,
    as: "a",
    href: "#"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: 16,
      color: "var(--text-1)"
    }
  }, d.titulo), /*#__PURE__*/React.createElement(DSb.Badge, {
    tone: d.tipo === "publico" ? "success" : "warning"
  }, d.tipo === "publico" ? "Público" : "Interno")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      color: "var(--text-subtle)",
      lineHeight: 1.5,
      flex: 1,
      margin: 0
    }
  }, d.descricao), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: "var(--gold-700)"
    }
  }, "Abrir dashboard \u2192"))))));
}
window.DashboardsScreen = DashboardsScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dmtt/DashboardsScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dmtt/LinhasScreen.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// LinhasScreen — the core product view: line selector + dark map + sidebar
// (map style, horários, itinerário, busca por rua). Composes the DS primitives.
const DS = window.DMTTMaceiDesignSystem_aa209f;
const {
  MultiSelect,
  Select,
  SidebarPanel,
  Tabs,
  TimeChip,
  RouteBadge,
  ItineraryRow,
  OptionButton,
  Button
} = DS;
const LINHAS = [{
  id: "1",
  label: "001 — Centro / Benedito Bentes"
}, {
  id: "2",
  label: "012 — Jacintinho / Ponta Verde"
}, {
  id: "3",
  label: "023 — Cidade Universitária / Farol"
}, {
  id: "4",
  label: "047 — Tabuleiro / Centro"
}, {
  id: "5",
  label: "052 — Serraria / Jatiúca"
}, {
  id: "6",
  label: "710 — Trapiche / Pajuçara"
}];
const ITINERARIO = {
  nome: "012 — Jacintinho / Ponta Verde",
  ida: [{
    via: "Terminal do Jacintinho",
    match: "exato",
    codigo: "9001"
  }, {
    via: "Av. Menino Marcelo",
    match: "exato",
    codigo: "1023"
  }, {
    via: "Av. Fernandes Lima",
    match: "exato",
    codigo: "1104"
  }, {
    via: "Rua Barão de Anadia",
    match: "fuzzy",
    codigo: "0442"
  }, {
    via: "Av. Álvaro Otacílio (Orla)",
    match: "exato",
    codigo: "1330"
  }],
  volta: [{
    via: "Av. Álvaro Otacílio (Orla)",
    match: "exato",
    codigo: "1330"
  }, {
    via: "Rua Jangadeiros Alagoanos",
    match: "nao_encontrado"
  }, {
    via: "Av. Fernandes Lima",
    match: "exato",
    codigo: "1104"
  }, {
    via: "Terminal do Jacintinho",
    match: "exato",
    codigo: "9001"
  }]
};
const HORARIOS = {
  dia_util: {
    ida: ["05:10", "05:38", "06:04", "06:30", "06:58", "07:24", "07:50"],
    volta: ["05:45", "06:15", "06:48", "07:20", "07:55"]
  },
  sabado: {
    ida: ["05:30", "06:20", "07:10", "08:00"],
    volta: ["06:00", "07:00", "08:00"]
  },
  domingo: {
    ida: ["06:00", "07:30", "09:00"],
    volta: ["06:45", "08:15"]
  }
};
const MAP_STYLES = [{
  key: "claro",
  label: "Claro",
  sw: "#F2F4F7"
}, {
  key: "streets",
  label: "Ruas",
  sw: "#E4E7EC"
}, {
  key: "sat",
  label: "Satélite",
  sw: "#6E7B55"
}];
function LinhasScreen() {
  const [sel, setSel] = React.useState(["2"]);
  const [sentido, setSentido] = React.useState("ambos");
  const [mapStyle, setMapStyle] = React.useState("claro");
  const [terminais, setTerminais] = React.useState(true);
  const [dia, setDia] = React.useState("dia_util");
  const [rua, setRua] = React.useState("");
  const [contexto, setContexto] = React.useState(null);
  const single = sel.length === 1;
  const dh = HORARIOS[dia];
  function toggle(id) {
    setSel(p => p.includes(id) ? p.filter(x => x !== id) : [...p, id]);
    setContexto(null);
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      height: "100%",
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 16,
      padding: "10px 16px",
      background: "var(--surface-base)",
      borderBottom: "1px solid var(--border-2)",
      flexShrink: 0,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("label", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      color: "var(--text-subtle)"
    }
  }, "Linhas"), /*#__PURE__*/React.createElement(MultiSelect, {
    options: LINHAS,
    selectedIds: sel,
    onToggle: toggle,
    onClear: () => {
      setSel([]);
      setContexto(null);
    },
    panelWidth: 360
  })), /*#__PURE__*/React.createElement(Select, {
    label: "Sentido",
    value: sentido,
    onChange: e => setSentido(e.target.value)
  }, /*#__PURE__*/React.createElement("option", {
    value: "ambos"
  }, "Ida e Volta"), /*#__PURE__*/React.createElement("option", {
    value: "ida"
  }, "Somente Ida"), /*#__PURE__*/React.createElement("option", {
    value: "volta"
  }, "Somente Volta"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flex: 1,
      minHeight: 0,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      position: "relative",
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement(MapCanvas, {
    sentido: sentido,
    showTerminais: terminais,
    contexto: contexto,
    onClickPoint: () => {
      setRua("Av. Fernandes Lima");
      setContexto({
        linha: "012 — Jacintinho",
        sentido: "IDA",
        rua: "Av. Fernandes Lima"
      });
    }
  })), /*#__PURE__*/React.createElement("aside", {
    style: {
      width: 340,
      flexShrink: 0,
      display: "flex",
      flexDirection: "column",
      background: "var(--surface-base)",
      borderLeft: "1px solid var(--border-2)",
      overflowY: "auto"
    }
  }, /*#__PURE__*/React.createElement(SidebarPanel, {
    title: "Estilo do mapa"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 4,
      padding: "8px 16px 12px"
    }
  }, MAP_STYLES.map(m => /*#__PURE__*/React.createElement(OptionButton, {
    key: m.key,
    active: mapStyle === m.key,
    onClick: () => setMapStyle(m.key),
    swatch: /*#__PURE__*/React.createElement("span", {
      style: {
        width: 24,
        height: 24,
        borderRadius: 4,
        background: m.sw,
        border: "1px solid rgba(255,255,255,.15)"
      }
    })
  }, m.label)), /*#__PURE__*/React.createElement(OptionButton, {
    active: terminais,
    accent: "#F0A73B",
    accentSoft: "rgba(240,167,59,.14)",
    onClick: () => setTerminais(v => !v),
    swatch: /*#__PURE__*/React.createElement("span", {
      style: {
        width: 24,
        height: 24,
        borderRadius: "50%",
        background: "#F0A73B",
        border: "2px solid #0C0D10",
        boxShadow: "0 0 0 1px rgba(255,255,255,.15)"
      }
    })
  }, "Terminais"))), single && /*#__PURE__*/React.createElement(SidebarPanel, {
    title: "Hor\xE1rios"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "8px 16px 4px"
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    value: dia,
    onChange: setDia,
    items: [{
      key: "dia_util",
      label: "Dia Útil"
    }, {
      key: "sabado",
      label: "Sábado"
    }, {
      key: "domingo",
      label: "Domingo"
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      border: "1px solid var(--border-2)",
      borderTop: "none",
      borderRadius: "0 0 var(--radius) var(--radius)",
      padding: "10px 12px",
      display: "flex",
      flexDirection: "column",
      gap: 10,
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      textTransform: "uppercase",
      letterSpacing: "0.05em",
      color: "var(--ida)"
    }
  }, "\u2192 IDA"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 4
    }
  }, dh.ida.map(h => /*#__PURE__*/React.createElement(TimeChip, {
    key: h
  }, h)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      textTransform: "uppercase",
      letterSpacing: "0.05em",
      color: "var(--volta)"
    }
  }, "\u2190 VOLTA"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 4
    }
  }, dh.volta.map(h => /*#__PURE__*/React.createElement(TimeChip, {
    key: h
  }, h))))))), /*#__PURE__*/React.createElement(SidebarPanel, {
    title: "Itiner\xE1rio",
    hint: single ? null : "Selecione uma única linha para ver o itinerário."
  }, single && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      padding: "8px 16px",
      fontSize: 12,
      fontWeight: 600,
      color: "var(--text-subtle)",
      background: "var(--ink-800)"
    }
  }, ITINERARIO.nome), sentido !== "volta" && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 12,
      fontWeight: 700,
      padding: "8px 16px",
      borderLeft: "3px solid var(--ida)",
      color: "var(--text-subtle)",
      background: "var(--ink-800)"
    }
  }, "\u2192 IDA"), /*#__PURE__*/React.createElement("ul", {
    style: {
      margin: 0,
      padding: 0
    }
  }, ITINERARIO.ida.map((r, i) => /*#__PURE__*/React.createElement(ItineraryRow, _extends({
    key: i
  }, r))))), sentido !== "ida" && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 12,
      fontWeight: 700,
      padding: "8px 16px",
      borderLeft: "3px solid var(--volta)",
      color: "var(--text-subtle)",
      background: "var(--ink-800)"
    }
  }, "\u2190 VOLTA"), /*#__PURE__*/React.createElement("ul", {
    style: {
      margin: 0,
      padding: 0
    }
  }, ITINERARIO.volta.map((r, i) => /*#__PURE__*/React.createElement(ItineraryRow, _extends({
    key: i
  }, r))))))), /*#__PURE__*/React.createElement(SidebarPanel, {
    title: "Buscar por rua",
    divider: false
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "10px 16px 16px"
    }
  }, /*#__PURE__*/React.createElement(DS.SearchInput, {
    icon: /*#__PURE__*/React.createElement("span", null, "\u2315"),
    placeholder: "Ex.: Fernandes Lima",
    value: rua,
    onChange: e => setRua(e.target.value)
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 11,
      color: "var(--text-hint)",
      margin: "6px 0 0"
    }
  }, "Dica: clique em qualquer ponto do mapa para descobrir a rua."), rua.toLowerCase().includes("fernandes") && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 12
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      color: "var(--text-hint)",
      marginBottom: 8
    }
  }, "2 linha(s) em \"Fernandes Lima\""), [{
    n: "012 — Jacintinho / Ponta Verde",
    s: [["ida", "1104"], ["volta", "1104"]]
  }, {
    n: "023 — Cidade Universitária",
    s: [["ida", "2210"]]
  }].map((l, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      padding: "8px 0",
      borderBottom: "1px solid var(--border-1)"
    }
  }, /*#__PURE__*/React.createElement("button", {
    style: {
      background: "none",
      border: "none",
      padding: 0,
      fontSize: 13,
      fontWeight: 600,
      color: "var(--gold-700)",
      cursor: "pointer",
      marginBottom: 6,
      display: "block"
    },
    onClick: () => {
      setSel(["2"]);
      setContexto(null);
    }
  }, l.n), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 4,
      flexWrap: "wrap"
    }
  }, l.s.map(([sent, code], j) => /*#__PURE__*/React.createElement(RouteBadge, {
    key: j,
    sentido: sent,
    code: code,
    onClick: () => setContexto({
      linha: l.n,
      sentido: sent.toUpperCase(),
      rua: "Av. Fernandes Lima"
    })
  })))))))))));
}
window.LinhasScreen = LinhasScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dmtt/LinhasScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dmtt/MapCanvas.jsx
try { (() => {
// MapCanvas — stylized LIGHT map stand-in for the Leaflet/OSM view.
// The real product renders OpenStreetMap tiles with route polylines; here we
// evoke that with a light SVG basemap, IDA/VOLTA route lines, terminais, legend,
// and the contextual street callout.
const {
  useMemo
} = React;
function MapCanvas({
  sentido = "ambos",
  showTerminais = false,
  contexto = null,
  onClickPoint
}) {
  // faint pseudo-street grid
  const grid = useMemo(() => {
    const lines = [];
    for (let x = 40; x < 900; x += 64) lines.push({
      x1: x,
      y1: 0,
      x2: x + 90,
      y2: 620
    });
    for (let y = 30; y < 620; y += 58) lines.push({
      x1: 0,
      y1: y,
      x2: 900,
      y2: y - 40
    });
    return lines;
  }, []);
  const ida = "M 70 540 C 200 500, 250 380, 380 360 S 560 300, 660 200 S 790 120, 840 70";
  const volta = "M 840 96 C 780 150, 640 230, 560 300 S 360 380, 300 430 S 150 540, 80 560";
  return /*#__PURE__*/React.createElement("div", {
    onClick: e => {
      const r = e.currentTarget.getBoundingClientRect();
      onClickPoint && onClickPoint(e.clientX - r.left, e.clientY - r.top);
    },
    style: {
      position: "absolute",
      inset: 0,
      overflow: "hidden",
      cursor: "crosshair",
      background: "radial-gradient(120% 90% at 30% 20%, #F3F5F8 0%, #E9ECF1 60%, #E2E6EC 100%)"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 900 620",
    preserveAspectRatio: "xMidYMid slice",
    style: {
      position: "absolute",
      inset: 0,
      width: "100%",
      height: "100%"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 120 40 Q 260 30 300 120 T 240 250 Q 120 240 100 140 Z",
    fill: "#E2ECDD",
    opacity: "0.9"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M 0 470 C 200 440, 380 500, 560 470 S 900 420, 900 470 L 900 620 L 0 620 Z",
    fill: "#D3E3EE",
    opacity: "0.95"
  }), /*#__PURE__*/React.createElement("g", {
    stroke: "#DEE2E8",
    strokeWidth: "1.5"
  }, grid.map((l, i) => /*#__PURE__*/React.createElement("line", {
    key: i,
    x1: l.x1,
    y1: l.y1,
    x2: l.x2,
    y2: l.y2
  }))), /*#__PURE__*/React.createElement("g", {
    stroke: "#CBD0D8",
    strokeWidth: "3.5",
    opacity: "0.9"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "0",
    y1: "250",
    x2: "900",
    y2: "200"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "120",
    y1: "0",
    x2: "220",
    y2: "620"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "560",
    y1: "0",
    x2: "600",
    y2: "620"
  })), sentido !== "volta" && /*#__PURE__*/React.createElement("path", {
    d: ida,
    fill: "none",
    stroke: "#16A34A",
    strokeWidth: "5",
    strokeLinecap: "round",
    style: {
      filter: "drop-shadow(0 1px 2px rgba(22,163,74,0.35))"
    }
  }), sentido !== "ida" && /*#__PURE__*/React.createElement("path", {
    d: volta,
    fill: "none",
    stroke: "#2E64D4",
    strokeWidth: "5",
    strokeLinecap: "round",
    style: {
      filter: "drop-shadow(0 1px 2px rgba(46,100,212,0.35))"
    }
  }), showTerminais && [[70, 540], [840, 70], [380, 360]].map(([cx, cy], i) => /*#__PURE__*/React.createElement("g", {
    key: i
  }, /*#__PURE__*/React.createElement("circle", {
    cx: cx,
    cy: cy,
    r: "9",
    fill: "#D98407",
    stroke: "#FFFFFF",
    strokeWidth: "3",
    style: {
      filter: "drop-shadow(0 1px 2px rgba(18,24,40,0.25))"
    }
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      bottom: 20,
      left: 14,
      display: "flex",
      gap: 12,
      background: "rgba(255,255,255,0.92)",
      border: "1px solid var(--border-2)",
      borderRadius: "var(--radius)",
      padding: "6px 12px",
      fontSize: 12,
      fontWeight: 600,
      color: "var(--text-2)",
      backdropFilter: "blur(4px)",
      boxShadow: "var(--shadow-sm)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 5
    }
  }, /*#__PURE__*/React.createElement("i", {
    style: {
      width: 18,
      height: 4,
      borderRadius: 2,
      background: "#16A34A"
    }
  }), "IDA"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 5
    }
  }, /*#__PURE__*/React.createElement("i", {
    style: {
      width: 18,
      height: 4,
      borderRadius: 2,
      background: "#2E64D4"
    }
  }), "VOLTA"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 5
    }
  }, /*#__PURE__*/React.createElement("i", {
    style: {
      width: 18,
      height: 4,
      borderRadius: 2,
      background: "#E0A400"
    }
  }), "Rua")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      bottom: 4,
      right: 8,
      fontSize: 10,
      color: "var(--text-4)"
    }
  }, "\xA9 OpenStreetMap"), contexto && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      bottom: 60,
      right: 14,
      width: 250,
      padding: "11px 13px",
      background: "#FFFFFF",
      borderLeft: "3px solid var(--gold-400)",
      borderRadius: 6,
      boxShadow: "var(--shadow-lg)",
      fontSize: 12,
      color: "var(--text-2)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      color: "var(--gold-700)",
      textTransform: "uppercase",
      letterSpacing: "0.04em",
      marginBottom: 5
    }
  }, "Rua identificada"), /*#__PURE__*/React.createElement("div", {
    style: {
      lineHeight: 1.5,
      marginBottom: 8
    }
  }, "Mostrando ", /*#__PURE__*/React.createElement("strong", {
    style: {
      color: "var(--text-1)"
    }
  }, contexto.linha), " no sentido ", /*#__PURE__*/React.createElement("em", {
    style: {
      fontStyle: "normal",
      color: "var(--warning-text)",
      fontWeight: 700
    }
  }, contexto.sentido), " que passa em ", /*#__PURE__*/React.createElement("strong", {
    style: {
      color: "var(--text-1)"
    }
  }, contexto.rua), ".")));
}
window.MapCanvas = MapCanvas;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dmtt/MapCanvas.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dmtt/SobreScreen.jsx
try { (() => {
// SobreScreen — "about" prose page.
function SobreScreen() {
  const H = ({
    children
  }) => /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 600,
      fontSize: 19,
      color: "var(--text-1)",
      margin: "26px 0 8px"
    }
  }, children);
  const P = ({
    children
  }) => /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 14,
      color: "var(--text-subtle)",
      lineHeight: 1.65,
      marginBottom: 8,
      maxWidth: 620
    }
  }, children);
  const S = ({
    children
  }) => /*#__PURE__*/React.createElement("strong", {
    style: {
      color: "var(--text-1)",
      fontWeight: 700
    }
  }, children);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      overflowY: "auto",
      padding: "32px 36px 56px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 900
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: 26,
      color: "var(--text-1)",
      marginBottom: 10
    }
  }, "Sobre o sistema"), /*#__PURE__*/React.createElement(P, null, "O ", /*#__PURE__*/React.createElement(S, null, "Linhas DMTT"), " \xE9 um sistema da DMTT (Diretoria de Mobilidade e Tr\xE2nsito de Macei\xF3/AL) para consulta de itiner\xE1rios de \xF4nibus, criado pelo setor GEPOT."), /*#__PURE__*/React.createElement(H, null, "O que ele resolve"), /*#__PURE__*/React.createElement(P, null, "Quando o setor recebe uma reclama\xE7\xE3o sobre um \xF4nibus, \xE9 preciso descobrir qual linha passava por determinada rua em determinado hor\xE1rio. Este sistema permite:"), /*#__PURE__*/React.createElement("ul", {
    style: {
      fontSize: 14,
      color: "var(--text-subtle)",
      lineHeight: 1.8,
      paddingLeft: 20,
      maxWidth: 620
    }
  }, /*#__PURE__*/React.createElement("li", null, "Visualizar o tra\xE7ado de qualquer linha no mapa, com os sentidos IDA e VOLTA."), /*#__PURE__*/React.createElement("li", null, "Ver o itiner\xE1rio completo (ruas atendidas) e o quadro de hor\xE1rios por linha."), /*#__PURE__*/React.createElement("li", null, "Buscar por nome de rua e listar todas as linhas que passam ali."), /*#__PURE__*/React.createElement("li", null, "Filtrar essa busca por hor\xE1rio (janela de \xB120 min) para identificar o \xF4nibus prov\xE1vel."), /*#__PURE__*/React.createElement("li", null, "Clicar em qualquer ponto do mapa para descobrir automaticamente a rua e as linhas que a atendem.")), /*#__PURE__*/React.createElement(H, null, "Dashboards"), /*#__PURE__*/React.createElement(P, null, "A se\xE7\xE3o ", /*#__PURE__*/React.createElement(S, null, "Dashboards"), " re\xFAne os relat\xF3rios e indicadores do GEPOT publicados no Power BI, centralizando o acesso num \xFAnico lugar."), /*#__PURE__*/React.createElement(H, null, "Como os dados funcionam"), /*#__PURE__*/React.createElement(P, null, "O sistema \xE9 totalmente est\xE1tico \u2014 sem servidor rodando em produ\xE7\xE3o. Os dados de linhas, itiner\xE1rios e hor\xE1rios s\xE3o gerados a partir da base oficial do setor e publicados junto com o site.")));
}
window.SobreScreen = SobreScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dmtt/SobreScreen.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.MultiSelect = __ds_scope.MultiSelect;

__ds_ns.OptionButton = __ds_scope.OptionButton;

__ds_ns.SearchInput = __ds_scope.SearchInput;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.NavBar = __ds_scope.NavBar;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.ItineraryRow = __ds_scope.ItineraryRow;

__ds_ns.MatchMark = __ds_scope.MatchMark;

__ds_ns.RouteBadge = __ds_scope.RouteBadge;

__ds_ns.SidebarPanel = __ds_scope.SidebarPanel;

__ds_ns.TimeChip = __ds_scope.TimeChip;

})();
