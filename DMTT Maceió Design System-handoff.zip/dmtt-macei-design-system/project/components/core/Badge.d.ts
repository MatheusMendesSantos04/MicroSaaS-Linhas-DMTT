import * as React from "react";

/** Small status pill: dashboard access type, loading/error, generic labels. */
export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  children?: React.ReactNode;
  /** @default "neutral" */
  tone?: "neutral" | "gold" | "success" | "warning" | "danger" | "info";
  /** @default "md" */
  size?: "sm" | "md";
}
export function Badge(props: BadgeProps): JSX.Element;
