import React from "react";

/**
 * Badge — small status pill. Used for dashboard access type (Público / Interno),
 * loading / error states, and generic labels.
 */
export function Badge({ children, tone = "neutral", size = "md", style = {}, ...rest }) {
  const tones = {
    neutral: { background: "var(--surface-base)", color: "var(--text-subtle)", border: "1px solid var(--border-2)" },
    gold:    { background: "rgba(228,178,30,0.14)", color: "var(--gold-700)", border: "1px solid rgba(228,178,30,0.42)" },
    success: { background: "var(--success-soft)", color: "var(--success-text)", border: "1px solid rgba(22,163,74,0.30)" },
    warning: { background: "var(--warning-soft)", color: "var(--warning-text)", border: "1px solid rgba(217,132,7,0.32)" },
    danger:  { background: "var(--danger-soft)", color: "var(--danger-text)", border: "1px solid rgba(220,38,38,0.28)" },
    info:    { background: "var(--info-soft)", color: "#1E4FB0", border: "1px solid rgba(46,100,212,0.30)" },
  };
  const sizes = {
    sm: { padding: "1px 6px", fontSize: "var(--fs-2xs)" },
    md: { padding: "2px 8px", fontSize: "var(--fs-2xs)" },
  };
  const t = tones[tone] || tones.neutral;
  const s = sizes[size] || sizes.md;
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 4,
        fontFamily: "var(--font-sans)",
        fontWeight: "var(--fw-bold)",
        textTransform: "uppercase",
        letterSpacing: "var(--ls-wide)",
        lineHeight: 1.4,
        borderRadius: "var(--radius-sm)",
        whiteSpace: "nowrap",
        ...t,
        ...s,
        ...style,
      }}
      {...rest}
    >
      {children}
    </span>
  );
}
