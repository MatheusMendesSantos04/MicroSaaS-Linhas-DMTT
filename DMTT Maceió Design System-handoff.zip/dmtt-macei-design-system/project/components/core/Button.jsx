import React from "react";

/**
 * Button — primary action control for the DMTT interface.
 * Gold primary on dark; compact by default (this is a dense operational tool).
 */
export function Button({
  children,
  variant = "primary",
  size = "md",
  disabled = false,
  fullWidth = false,
  iconLeft = null,
  iconRight = null,
  type = "button",
  onClick,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: { padding: "5px 10px", fontSize: "var(--fs-xs)", height: 28, gap: 6 },
    md: { padding: "8px 16px", fontSize: "var(--fs-sm)", height: 36, gap: 8 },
    lg: { padding: "11px 22px", fontSize: "var(--fs-body)", height: 44, gap: 8 },
  };
  const variants = {
    primary: {
      background: "var(--primary)",
      color: "var(--on-primary)",
      border: "1px solid transparent",
      fontWeight: "var(--fw-bold)",
    },
    secondary: {
      background: "var(--surface-input)",
      color: "var(--text-body)",
      border: "1px solid var(--border-2)",
      fontWeight: "var(--fw-semibold)",
    },
    ghost: {
      background: "transparent",
      color: "var(--text-subtle)",
      border: "1px solid transparent",
      fontWeight: "var(--fw-semibold)",
    },
    danger: {
      background: "var(--danger-soft)",
      color: "var(--danger-text)",
      border: "1px solid rgba(242,96,96,0.35)",
      fontWeight: "var(--fw-semibold)",
    },
  };
  const s = sizes[size] || sizes.md;
  const v = variants[variant] || variants.primary;

  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);

  const hoverStyle =
    !disabled && hover
      ? variant === "primary"
        ? { background: "var(--primary-hover)" }
        : variant === "ghost"
        ? { background: "var(--surface-hover)", color: "var(--text-body)" }
        : { borderColor: "var(--border-3)", background: "var(--surface-hover)" }
      : {};

  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => { setHover(false); setActive(false); }}
      onMouseDown={() => setActive(true)}
      onMouseUp={() => setActive(false)}
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        gap: s.gap,
        width: fullWidth ? "100%" : "auto",
        height: s.height,
        padding: s.padding,
        fontFamily: "var(--font-sans)",
        fontSize: s.fontSize,
        lineHeight: 1,
        letterSpacing: "0.01em",
        borderRadius: "var(--radius)",
        cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.45 : 1,
        transform: active && !disabled ? "translateY(1px)" : "none",
        transition: "background var(--dur-fast) var(--ease-std), border-color var(--dur-fast), transform var(--dur-fast), color var(--dur-fast)",
        whiteSpace: "nowrap",
        ...v,
        ...hoverStyle,
        ...style,
      }}
      {...rest}
    >
      {iconLeft}
      {children}
      {iconRight}
    </button>
  );
}
