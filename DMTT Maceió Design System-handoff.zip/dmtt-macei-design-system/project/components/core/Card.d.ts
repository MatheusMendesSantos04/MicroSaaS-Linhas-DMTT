import * as React from "react";

/**
 * Raised surface container. `interactive` adds gold hover border + lift (Dashboards grid).
 * @startingPoint section="Core" subtitle="Card surface — static & interactive" viewport="700x200"
 */
export interface CardProps extends React.HTMLAttributes<HTMLElement> {
  children?: React.ReactNode;
  interactive?: boolean;
  /** Render as a different element, e.g. "a". @default "div" */
  as?: keyof JSX.IntrinsicElements;
  padding?: string;
}
export function Card(props: CardProps): JSX.Element;
