import React from "react";

/**
 * Card — raised surface container. `interactive` adds gold hover border + lift,
 * used for the Dashboards grid (each card is a link to a Power BI report).
 */
export function Card({
  children,
  interactive = false,
  as = "div",
  padding = "var(--sp-6)",
  style = {},
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const Tag = as;
  return (
    <Tag
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: "flex",
        flexDirection: "column",
        gap: "var(--sp-4)",
        padding,
        background: "var(--surface-card)",
        border: "1px solid var(--border-card)",
        borderRadius: "var(--radius-md)",
        color: "var(--text-body)",
        textDecoration: "none",
        boxShadow: "var(--shadow-sm)",
        transition: "border-color var(--dur) var(--ease-std), box-shadow var(--dur), transform var(--dur)",
        ...(interactive && hover
          ? {
              borderColor: "rgba(228,178,30,0.55)",
              boxShadow: "var(--shadow-md)",
              transform: "translateY(-2px)",
              cursor: "pointer",
            }
          : {}),
        ...style,
      }}
      {...rest}
    >
      {children}
    </Tag>
  );
}
