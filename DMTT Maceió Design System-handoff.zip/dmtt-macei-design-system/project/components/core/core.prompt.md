Core UI primitives — Button, Badge, Card. Use for actions, status pills, and content surfaces across the DMTT interface.

```jsx
<Button variant="primary" size="md">Abrir dashboard</Button>
<Button variant="secondary" iconLeft={<span>↺</span>}>Limpar</Button>
<Badge tone="success">Público</Badge>
<Badge tone="warning">Interno</Badge>
<Card interactive as="a" href="#">
  <strong>Frota e Quilometragem</strong>
  <p>Quilometragem rodada por linha.</p>
</Card>
```

- **Button** variants: `primary` (gold fill), `secondary` (bordered surface), `ghost`, `danger`. Sizes `sm | md | lg`.
- **Badge** tones map to meaning: `success`=Público, `warning`=Interno, `danger`=erro, `gold`=brand highlight.
- **Card** `interactive` for clickable cards; set `as="a"` to make the whole card a link.
