import * as React from "react";

export interface MultiSelectOption { id: string | number; label: string; }

/**
 * Searchable checkbox dropdown — the map line selector.
 * @startingPoint section="Forms" subtitle="Searchable multi-select dropdown" viewport="700x120"
 */
export interface MultiSelectProps {
  options: MultiSelectOption[];
  selectedIds: (string | number)[];
  onToggle?: (id: string | number) => void;
  onClear?: () => void;
  placeholder?: string;
  panelWidth?: number;
  style?: React.CSSProperties;
}
export function MultiSelect(props: MultiSelectProps): JSX.Element;
