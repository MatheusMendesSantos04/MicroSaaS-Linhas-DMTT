import React from "react";

/**
 * MultiSelect — searchable checkbox dropdown. The line selector on the map view:
 * pick one line to see its full itinerary, or several to overlay their routes.
 * `options` is [{ id, label }]. Controlled via `selectedIds` + `onToggle`.
 */
export function MultiSelect({
  options = [],
  selectedIds = [],
  onToggle,
  onClear,
  placeholder = "Todas as linhas",
  panelWidth = 460,
  style = {},
}) {
  const [open, setOpen] = React.useState(false);
  const [search, setSearch] = React.useState("");
  const ref = React.useRef(null);

  React.useEffect(() => {
    if (!open) return;
    function h(e) { if (ref.current && !ref.current.contains(e.target)) setOpen(false); }
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, [open]);

  const filtered = search.trim()
    ? options.filter((o) => o.label.toLowerCase().includes(search.toLowerCase()))
    : options;

  const label =
    selectedIds.length === 0
      ? placeholder
      : selectedIds.length === 1
      ? options.find((o) => o.id === selectedIds[0])?.label ?? "1 selecionada"
      : `${selectedIds.length} linhas selecionadas`;

  return (
    <div ref={ref} style={{ position: "relative", display: "inline-flex", alignItems: "center", gap: 4, ...style }}>
      <button
        onClick={() => setOpen((v) => !v)}
        style={{
          display: "flex",
          alignItems: "center",
          gap: 8,
          minWidth: 260,
          height: 34,
          padding: "0 10px",
          textAlign: "left",
          fontFamily: "var(--font-sans)",
          fontSize: "var(--fs-sm)",
          color: "var(--text-body)",
          background: "var(--surface-input)",
          border: `1px solid ${open ? "var(--focus-ring)" : "var(--border-input)"}`,
          boxShadow: open ? "var(--shadow-focus)" : "none",
          borderRadius: "var(--radius)",
          cursor: "pointer",
        }}
      >
        <span style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{label}</span>
        <span style={{ fontSize: 8, color: "var(--text-hint)" }}>{open ? "▲" : "▼"}</span>
      </button>

      {selectedIds.length > 0 && (
        <button
          onClick={() => { onClear && onClear(); setSearch(""); }}
          title="Limpar seleção"
          style={{
            width: 24, height: 24, flexShrink: 0,
            border: "none", borderRadius: "50%",
            background: "var(--ink-500)", color: "var(--text-subtle)",
            fontSize: 11, cursor: "pointer",
            display: "flex", alignItems: "center", justifyContent: "center",
          }}
        >✕</button>
      )}

      {open && (
        <div
          style={{
            position: "absolute", top: "calc(100% + 6px)", left: 0, zIndex: 3000,
            width: panelWidth, maxHeight: 340, display: "flex", flexDirection: "column",
            background: "var(--surface-card)",
            border: "1px solid var(--border-3)",
            borderRadius: "var(--radius-md)",
            boxShadow: "var(--shadow-pop)",
            overflow: "hidden",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 8, padding: 8, borderBottom: "1px solid var(--border-1)" }}>
            <input
              autoFocus value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder="Filtrar linha…"
              style={{
                flex: 1, height: 30, padding: "0 8px",
                background: "var(--surface-input)", border: "1px solid var(--border-2)",
                borderRadius: "var(--radius)", color: "var(--text-body)",
                fontFamily: "var(--font-sans)", fontSize: "var(--fs-sm)", outline: "none",
              }}
            />
            {selectedIds.length > 0 && (
              <span style={{
                fontSize: "var(--fs-2xs)", fontWeight: "var(--fw-bold)",
                color: "var(--on-primary)", background: "var(--primary)",
                borderRadius: 999, padding: "2px 8px", whiteSpace: "nowrap",
              }}>{selectedIds.length} ✓</span>
            )}
          </div>
          <div style={{ overflowY: "auto", flex: 1 }}>
            {filtered.length === 0 && (
              <p style={{ padding: 12, fontSize: "var(--fs-sm)", color: "var(--text-hint)" }}>Nenhuma linha encontrada</p>
            )}
            {filtered.map((o) => {
              const checked = selectedIds.includes(o.id);
              return (
                <label
                  key={o.id}
                  style={{
                    display: "flex", alignItems: "center", gap: 9,
                    padding: "8px 12px", cursor: "pointer",
                    fontSize: "var(--fs-sm)", color: "var(--text-body)",
                    borderBottom: "1px solid var(--border-1)",
                    background: checked ? "rgba(233,183,41,0.10)" : "transparent",
                    userSelect: "none",
                  }}
                >
                  <input
                    type="checkbox" checked={checked} onChange={() => onToggle && onToggle(o.id)}
                    style={{ width: 15, height: 15, accentColor: "var(--primary)", cursor: "pointer" }}
                  />
                  <span>{o.label}</span>
                </label>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
