import * as React from "react";

/** Full-width selectable list row with leading swatch + active state (map styles, Terminais toggle). */
export interface OptionButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children?: React.ReactNode;
  active?: boolean;
  swatch?: React.ReactNode;
  /** Active/hover accent color. @default gold */
  accent?: string;
  accentSoft?: string;
}
export function OptionButton(props: OptionButtonProps): JSX.Element;
