import React from "react";

/**
 * OptionButton — full-width selectable list row with a leading swatch/icon and
 * an active state. Used for map-style choices and the Terminais toggle.
 * `accent` recolors the active + hover state (gold by default; orange for Terminais).
 */
export function OptionButton({
  children,
  active = false,
  swatch = null,
  accent = "var(--primary)",
  accentSoft = "rgba(233,183,41,0.14)",
  onClick,
  style = {},
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: "flex",
        alignItems: "center",
        gap: 10,
        width: "100%",
        padding: "8px 10px",
        textAlign: "left",
        fontFamily: "var(--font-sans)",
        fontSize: "var(--fs-sm)",
        fontWeight: active ? "var(--fw-semibold)" : "var(--fw-regular)",
        color: active ? accent : "var(--text-body)",
        background: active ? accentSoft : hover ? "var(--surface-hover)" : "var(--surface-input)",
        border: `1px solid ${active || hover ? accent : "var(--border-2)"}`,
        borderRadius: "var(--radius)",
        cursor: "pointer",
        transition: "border-color var(--dur-fast), background var(--dur-fast), color var(--dur-fast)",
        ...style,
      }}
      {...rest}
    >
      {swatch}
      <span style={{ flex: 1 }}>{children}</span>
      {active && <span style={{ fontSize: 12, fontWeight: "var(--fw-bold)", color: accent }}>✓</span>}
    </button>
  );
}
