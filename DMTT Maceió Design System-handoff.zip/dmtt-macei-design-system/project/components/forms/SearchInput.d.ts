import * as React from "react";

/** Text field with optional leading icon + trailing spinner (street search, line filter). */
export interface SearchInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  icon?: React.ReactNode;
  loading?: boolean;
  /** @default "md" */
  size?: "sm" | "md";
  fullWidth?: boolean;
}
export function SearchInput(props: SearchInputProps): JSX.Element;
