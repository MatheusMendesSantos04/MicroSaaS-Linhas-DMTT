import React from "react";

/**
 * SearchInput — text field with optional leading icon and trailing spinner.
 * Used for the street search (autocomplete) and the line filter.
 */
export function SearchInput({
  value,
  onChange,
  placeholder = "",
  icon = null,
  loading = false,
  size = "md",
  fullWidth = true,
  style = {},
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const sizes = {
    sm: { height: 32, fontSize: "var(--fs-sm)", pad: 8 },
    md: { height: 38, fontSize: "var(--fs-sm)", pad: 10 },
  };
  const s = sizes[size] || sizes.md;
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 8,
        width: fullWidth ? "100%" : "auto",
        height: s.height,
        padding: `0 ${s.pad}px`,
        background: "var(--surface-input)",
        border: `1px solid ${focus ? "var(--focus-ring)" : "var(--border-input)"}`,
        borderRadius: "var(--radius)",
        boxShadow: focus ? "var(--shadow-focus)" : "none",
        transition: "border-color var(--dur-fast), box-shadow var(--dur-fast)",
        ...style,
      }}
    >
      {icon && (
        <span style={{ display: "flex", color: "var(--text-hint)", flexShrink: 0 }}>{icon}</span>
      )}
      <input
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        onFocus={() => setFocus(true)}
        onBlur={() => setFocus(false)}
        autoComplete="off"
        style={{
          flex: 1,
          minWidth: 0,
          background: "transparent",
          border: "none",
          outline: "none",
          color: "var(--text-body)",
          fontFamily: "var(--font-sans)",
          fontSize: s.fontSize,
        }}
        {...rest}
      />
      {loading && (
        <span style={{ color: "var(--text-hint)", fontSize: 13, flexShrink: 0 }}>…</span>
      )}
    </div>
  );
}
