import * as React from "react";

/** Styled native select for the dark theme (Sentido, Dia…). */
export interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: React.ReactNode;
  /** @default "md" */
  size?: "sm" | "md";
}
export function Select(props: SelectProps): JSX.Element;
