import React from "react";

/**
 * Select — styled native select for the dark theme (Sentido, Dia, etc.).
 * Wrap with a label externally, or pass `label` for an inline eyebrow.
 */
export function Select({
  value,
  onChange,
  children,
  label = null,
  size = "md",
  style = {},
  ...rest
}) {
  const sizes = {
    sm: { padding: "5px 26px 5px 8px", fontSize: "var(--fs-xs)", height: 30 },
    md: { padding: "7px 30px 7px 10px", fontSize: "var(--fs-sm)", height: 34 },
  };
  const s = sizes[size] || sizes.md;
  const select = (
    <div style={{ position: "relative", display: "inline-flex", alignItems: "center" }}>
      <select
        value={value}
        onChange={onChange}
        style={{
          appearance: "none",
          WebkitAppearance: "none",
          fontFamily: "var(--font-sans)",
          color: "var(--text-body)",
          background: "var(--surface-input)",
          border: "1px solid var(--border-input)",
          borderRadius: "var(--radius)",
          cursor: "pointer",
          outline: "none",
          ...s,
          ...style,
        }}
        {...rest}
      >
        {children}
      </select>
      <span
        aria-hidden
        style={{
          position: "absolute",
          right: 10,
          pointerEvents: "none",
          fontSize: 9,
          color: "var(--text-hint)",
        }}
      >
        ▼
      </span>
    </div>
  );
  if (!label) return select;
  return (
    <label style={{ display: "inline-flex", alignItems: "center", gap: "var(--sp-4)" }}>
      <span
        style={{
          fontSize: "var(--fs-xs)",
          fontWeight: "var(--fw-semibold)",
          color: "var(--text-subtle)",
          whiteSpace: "nowrap",
        }}
      >
        {label}
      </span>
      {select}
    </label>
  );
}
