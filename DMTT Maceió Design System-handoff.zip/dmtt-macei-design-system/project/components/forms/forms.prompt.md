Form controls for the dark theme — Select, SearchInput, MultiSelect, OptionButton.

```jsx
<Select label="Sentido" value={s} onChange={e => setS(e.target.value)}>
  <option value="ambos">Ida e Volta</option>
  <option value="ida">Somente Ida</option>
</Select>

<SearchInput icon={<span>⌕</span>} placeholder="Ex.: Fernandes Lima"
  value={q} onChange={e => setQ(e.target.value)} loading={busy} />

<MultiSelect options={linhas} selectedIds={sel} onToggle={toggle} onClear={clear} />

<OptionButton active swatch={<span style={{width:26,height:26,borderRadius:4,background:'#1b2a3a'}} />}>
  Escuro
</OptionButton>
<OptionButton active accent="#F0A73B" accentSoft="rgba(240,167,59,.14)"
  swatch={<span style={{width:26,height:26,borderRadius:'50%',background:'#F0A73B'}} />}>
  Terminais
</OptionButton>
```

- **MultiSelect** `options` = `[{id, label}]`; controlled via `selectedIds` + `onToggle`/`onClear`.
- **OptionButton** re-tint the active/hover state per group with `accent` + `accentSoft`.
