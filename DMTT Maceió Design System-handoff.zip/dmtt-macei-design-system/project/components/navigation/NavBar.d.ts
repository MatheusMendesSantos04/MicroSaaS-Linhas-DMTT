import * as React from "react";

export interface NavBarLink { label: string; href?: string; active?: boolean; onClick?: (e: React.MouseEvent) => void; }

/**
 * Top application bar — badge mark + wordmark, right-aligned nav links.
 * @startingPoint section="Navigation" subtitle="Top app bar with brand + links" viewport="900x64"
 */
export interface NavBarProps {
  brand?: string;
  subtitle?: string;
  logoSrc?: string;
  links?: NavBarLink[];
  style?: React.CSSProperties;
}
export function NavBar(props: NavBarProps): JSX.Element;
