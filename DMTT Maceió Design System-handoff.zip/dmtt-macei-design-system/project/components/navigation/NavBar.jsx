import React from "react";

/**
 * NavBar — top application bar. Badge mark + wordmark on the left, nav links
 * on the right. Links: [{ label, href, active }].
 */
export function NavBar({
  brand = "Linhas DMTT",
  subtitle = "Maceió",
  logoSrc = null,
  links = [],
  style = {},
}) {
  return (
    <header
      style={{
        display: "flex",
        alignItems: "center",
        gap: "var(--sp-8)",
        height: "var(--topbar-h)",
        padding: "0 var(--sp-6)",
        background: "var(--surface-topbar)",
        borderBottom: "1px solid var(--border-2)",
        flexShrink: 0,
        ...style,
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 10, minWidth: 0 }}>
        {logoSrc && (
          <img
            src={logoSrc}
            alt=""
            style={{ height: 36, width: "auto", display: "block", flexShrink: 0 }}
          />
        )}
        <div style={{ display: "flex", flexDirection: "column", lineHeight: 1.05, minWidth: 0 }}>
          <span
            style={{
              fontFamily: "var(--font-display)",
              fontWeight: "var(--fw-bold)",
              fontSize: 18,
              letterSpacing: "0.01em",
              color: "var(--text-1)",
              whiteSpace: "nowrap",
            }}
          >
            {brand}
          </span>
          {subtitle && (
            <span
              style={{
                fontSize: "var(--fs-2xs)",
                fontWeight: "var(--fw-semibold)",
                letterSpacing: "var(--ls-caps)",
                textTransform: "uppercase",
                color: "var(--gold-600)",
              }}
            >
              {subtitle}
            </span>
          )}
        </div>
      </div>

      <nav style={{ display: "flex", gap: 4, marginLeft: "auto" }}>
        {links.map((l) => (
          <NavLink key={l.label} {...l} />
        ))}
      </nav>
    </header>
  );
}

function NavLink({ label, href = "#", active = false, onClick }) {
  const [hover, setHover] = React.useState(false);
  return (
    <a
      href={href}
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        padding: "7px 13px",
        borderRadius: "var(--radius)",
        fontSize: "var(--fs-sm)",
        fontWeight: "var(--fw-semibold)",
        textDecoration: "none",
        color: active ? "var(--text-1)" : hover ? "var(--text-1)" : "var(--text-3)",
        background: active
          ? "rgba(228,178,30,0.16)"
          : hover
          ? "var(--surface-hover)"
          : "transparent",
        boxShadow: active ? "inset 0 -2px 0 var(--gold-400)" : "none",
        transition: "background var(--dur-fast), color var(--dur-fast)",
      }}
    >
      {label}
    </a>
  );
}
