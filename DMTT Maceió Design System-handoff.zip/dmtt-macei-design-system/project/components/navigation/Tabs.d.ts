import * as React from "react";

export interface TabItem { key: string; label: React.ReactNode; }

/** Segmented tabs that connect to the panel body below (horários day switcher). */
export interface TabsProps {
  items: TabItem[];
  value: string;
  onChange?: (key: string) => void;
  style?: React.CSSProperties;
}
export function Tabs(props: TabsProps): JSX.Element;
