import React from "react";

/**
 * Tabs — segmented control that connects to the panel body below it (the
 * horários day switcher: Dia Útil / Sábado / Domingo).
 * `items` = [{ key, label }]. Controlled via `value` + `onChange`.
 */
export function Tabs({ items = [], value, onChange, style = {} }) {
  return (
    <div style={{ display: "flex", gap: 4, ...style }}>
      {items.map((it) => {
        const active = it.key === value;
        return (
          <button
            key={it.key}
            onClick={() => onChange && onChange(it.key)}
            style={{
              flex: 1,
              padding: "6px 4px",
              fontFamily: "var(--font-sans)",
              fontSize: "var(--fs-xs)",
              fontWeight: "var(--fw-semibold)",
              color: active ? "var(--gold-700)" : "var(--text-3)",
              background: active ? "var(--surface-card)" : "var(--surface-input)",
              border: "1px solid var(--border-2)",
              borderBottom: active ? "1px solid var(--surface-card)" : "1px solid var(--border-2)",
              borderRadius: "var(--radius) var(--radius) 0 0",
              cursor: "pointer",
              position: "relative",
              marginBottom: -1,
              zIndex: active ? 1 : 0,
              transition: "color var(--dur-fast), background var(--dur-fast)",
            }}
          >
            {it.label}
          </button>
        );
      })}
    </div>
  );
}
