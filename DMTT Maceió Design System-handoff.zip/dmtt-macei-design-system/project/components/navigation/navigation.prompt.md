Navigation — NavBar (top app bar) and Tabs (segmented day switcher).

```jsx
<NavBar
  brand="Linhas DMTT" subtitle="Maceió"
  logoSrc="assets/logo-policiamento-viario.png"
  links={[
    { label: "Linhas", href: "#", active: true },
    { label: "Dashboards", href: "#" },
    { label: "Sobre", href: "#" },
  ]}
/>

<Tabs value={dia} onChange={setDia} items={[
  { key: "dia_util", label: "Dia Útil" },
  { key: "sabado", label: "Sábado" },
  { key: "domingo", label: "Domingo" },
]} />
```

- **NavBar** links carry their own `active` flag; the active link gets a gold underline + tint.
- **Tabs** are designed to sit directly on top of a bordered panel body (the active tab merges into it).
