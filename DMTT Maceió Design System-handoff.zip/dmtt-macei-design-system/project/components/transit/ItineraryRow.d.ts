import * as React from "react";

/** One street in a line itinerary: match mark + name + optional official code. Render inside a <ul>. */
export interface ItineraryRowProps {
  via: string;
  match?: "exato" | "exato_global" | "fuzzy" | "fuzzy_global" | "contem" | "exato_sem_complemento" | "nao_encontrado";
  codigo?: string;
  style?: React.CSSProperties;
}
export function ItineraryRow(props: ItineraryRowProps): JSX.Element;
