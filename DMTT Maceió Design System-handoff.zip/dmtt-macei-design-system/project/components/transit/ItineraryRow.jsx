import React from "react";
import { MatchMark } from "./MatchMark";
import { TimeChip } from "./TimeChip";

/**
 * ItineraryRow — one street in a line's itinerary: match mark + street name +
 * optional official code. Rows stack inside a SidebarPanel section.
 */
export function ItineraryRow({ via, match = "exato", codigo = null, style = {} }) {
  return (
    <li
      style={{
        display: "flex",
        alignItems: "center",
        gap: 6,
        padding: "6px 16px",
        fontSize: "var(--fs-sm)",
        color: "var(--text-body)",
        borderBottom: "1px solid var(--border-1)",
        listStyle: "none",
        ...style,
      }}
    >
      <MatchMark match={match} />
      <span style={{ flex: 1 }}>{via}</span>
      {codigo && <TimeChip variant="code">{codigo}</TimeChip>}
    </li>
  );
}
