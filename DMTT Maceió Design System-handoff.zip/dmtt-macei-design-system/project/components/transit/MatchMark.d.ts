import * as React from "react";

/** Itinerary match indicator: exact ✓ (green), fuzzy ~ (amber), none ? (muted). */
export interface MatchMarkProps {
  /** @default "exato" */
  match?: "exato" | "exato_global" | "fuzzy" | "fuzzy_global" | "contem" | "exato_sem_complemento" | "nao_encontrado";
  style?: React.CSSProperties;
}
export function MatchMark(props: MatchMarkProps): JSX.Element;
