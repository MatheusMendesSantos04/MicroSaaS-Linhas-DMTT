import React from "react";

/**
 * MatchMark — itinerary code-match indicator. exact ✓ (green), fuzzy ~ (amber),
 * none ? (muted). Signals how confidently a street was matched to an official code.
 */
export function MatchMark({ match = "exato", style = {} }) {
  const MAP = {
    exato: { label: "✓", color: "var(--success)", title: "Match exato" },
    exato_global: { label: "✓", color: "var(--success)", title: "Match exato (global)" },
    fuzzy: { label: "~", color: "var(--warning)", title: "Match aproximado" },
    fuzzy_global: { label: "~", color: "var(--warning)", title: "Match aproximado (global)" },
    contem: { label: "~", color: "var(--warning)", title: "Match por contenção" },
    exato_sem_complemento: { label: "~", color: "var(--warning)", title: "Match sem complemento" },
    nao_encontrado: { label: "?", color: "var(--text-4)", title: "Código não encontrado" },
  };
  const m = MAP[match] || MAP.nao_encontrado;
  return (
    <span
      title={m.title}
      style={{
        display: "inline-block",
        width: 16,
        textAlign: "center",
        flexShrink: 0,
        fontFamily: "var(--font-mono)",
        fontSize: 11,
        fontWeight: "var(--fw-bold)",
        color: m.color,
        ...style,
      }}
    >
      {m.label}
    </span>
  );
}
