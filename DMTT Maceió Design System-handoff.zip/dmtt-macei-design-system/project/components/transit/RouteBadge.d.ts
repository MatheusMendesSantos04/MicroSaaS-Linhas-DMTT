import * as React from "react";

/** Direction badge — IDA (green) / VOLTA (blue), matching route colors on the map. */
export interface RouteBadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** @default "ida" */
  sentido?: "ida" | "volta";
  /** Optional mono code suffix. */
  code?: string;
  onClick?: (e: React.MouseEvent) => void;
}
export function RouteBadge(props: RouteBadgeProps): JSX.Element;
