import React from "react";

/**
 * RouteBadge — direction (sentido) badge. IDA = green, VOLTA = blue,
 * matching the route colors drawn on the map. Optional mono code suffix.
 * Pass `onClick` to make it an interactive filter chip.
 */
export function RouteBadge({ sentido = "ida", code = null, onClick, style = {}, ...rest }) {
  const isIda = sentido === "ida";
  const bg = isIda ? "var(--ida)" : "var(--volta)";
  const label = isIda ? "→ IDA" : "← VOLTA";
  const [hover, setHover] = React.useState(false);
  const clickable = !!onClick;
  return (
    <span
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 5,
        padding: "3px 9px",
        fontSize: "var(--fs-2xs)",
        fontWeight: "var(--fw-bold)",
        letterSpacing: "0.02em",
        color: "#08130B",
        background: bg,
        borderRadius: "var(--radius-sm)",
        cursor: clickable ? "pointer" : "default",
        filter: clickable && hover ? "brightness(1.1)" : "none",
        transform: clickable && hover ? "scale(1.04)" : "none",
        transition: "filter var(--dur-fast), transform var(--dur-fast)",
        whiteSpace: "nowrap",
        ...style,
      }}
      {...rest}
    >
      {label}
      {code && (
        <span style={{ fontFamily: "var(--font-mono)", fontSize: 10, opacity: 0.72, fontWeight: 500 }}>
          {code}
        </span>
      )}
    </span>
  );
}
