import * as React from "react";

/**
 * Titled section block for the map sidebar (uppercase eyebrow + body / empty-state hint).
 * @startingPoint section="Transit" subtitle="Titled sidebar section" viewport="360x220"
 */
export interface SidebarPanelProps {
  title?: React.ReactNode;
  /** Muted empty-state line shown instead of children. */
  hint?: React.ReactNode;
  children?: React.ReactNode;
  divider?: boolean;
  style?: React.CSSProperties;
}
export function SidebarPanel(props: SidebarPanelProps): JSX.Element;
