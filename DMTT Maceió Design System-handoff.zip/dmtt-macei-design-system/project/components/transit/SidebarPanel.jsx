import React from "react";

/**
 * SidebarPanel — titled section block for the map sidebar. Uppercase eyebrow
 * title + arbitrary body. `hint` renders a muted empty-state line instead of children.
 */
export function SidebarPanel({ title, hint = null, children, divider = true, style = {} }) {
  return (
    <section
      style={{
        borderBottom: divider ? "1px solid var(--border-2)" : "none",
        ...style,
      }}
    >
      {title && (
        <h2
          style={{
            fontFamily: "var(--font-sans)",
            fontSize: "var(--fs-xs)",
            fontWeight: "var(--fw-bold)",
            textTransform: "uppercase",
            letterSpacing: "var(--ls-caps)",
            color: "var(--text-subtle)",
            padding: "14px 16px 8px",
            borderBottom: "1px solid var(--border-1)",
          }}
        >
          {title}
        </h2>
      )}
      {hint ? (
        <p style={{ padding: "12px 16px", fontSize: "var(--fs-sm)", color: "var(--text-hint)" }}>{hint}</p>
      ) : (
        children
      )}
    </section>
  );
}
