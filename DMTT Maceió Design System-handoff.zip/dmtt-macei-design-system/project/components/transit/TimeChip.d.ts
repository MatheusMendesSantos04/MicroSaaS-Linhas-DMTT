import * as React from "react";

/** Monospace departure time, or an inline code (`variant="code"`). `highlight` = inside search window. */
export interface TimeChipProps extends React.HTMLAttributes<HTMLSpanElement> {
  children?: React.ReactNode;
  highlight?: boolean;
  /** @default "time" */
  variant?: "time" | "code";
}
export function TimeChip(props: TimeChipProps): JSX.Element;
