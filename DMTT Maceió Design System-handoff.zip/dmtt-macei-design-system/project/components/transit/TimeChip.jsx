import React from "react";

/**
 * TimeChip — a single departure time (monospace). `highlight` marks times inside
 * the ±20 min search window; `variant="code"` renders an inline street/line code.
 */
export function TimeChip({ children, highlight = false, variant = "time", style = {}, ...rest }) {
  if (variant === "code") {
    return (
      <span
        style={{
          fontFamily: "var(--font-mono)",
          fontSize: 10,
          color: "var(--text-hint)",
          background: "var(--ink-600)",
          borderRadius: "var(--radius-xs)",
          padding: "1px 5px",
          whiteSpace: "nowrap",
          ...style,
        }}
        {...rest}
      >
        {children}
      </span>
    );
  }
  return (
    <span
      style={{
        fontFamily: "var(--font-mono)",
        fontSize: "var(--fs-xs)",
        fontWeight: "var(--fw-semibold)",
        padding: "2px 8px",
        borderRadius: "var(--radius-sm)",
        color: highlight ? "var(--gold-100)" : "var(--text-body)",
        background: highlight ? "rgba(233,183,41,0.16)" : "var(--ink-600)",
        border: `1px solid ${highlight ? "rgba(233,183,41,0.45)" : "var(--border-2)"}`,
        whiteSpace: "nowrap",
        ...style,
      }}
      {...rest}
    >
      {children}
    </span>
  );
}
