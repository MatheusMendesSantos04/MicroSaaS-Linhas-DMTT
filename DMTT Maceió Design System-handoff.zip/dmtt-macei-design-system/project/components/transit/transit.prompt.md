Transit-domain primitives — the heart of the Linhas DMTT product. RouteBadge, TimeChip, MatchMark, SidebarPanel, ItineraryRow.

```jsx
<RouteBadge sentido="ida" code="01234" onClick={filterIda} />
<RouteBadge sentido="volta" />

<TimeChip>05:30</TimeChip>
<TimeChip highlight>06:12</TimeChip>   {/* inside ±20 min window */}
<TimeChip variant="code">RUA-8842</TimeChip>

<SidebarPanel title="Itinerário">
  <ul style={{ margin: 0, padding: 0 }}>
    <ItineraryRow via="Av. Fernandes Lima" match="exato" codigo="1023" />
    <ItineraryRow via="Rua do Comércio" match="fuzzy" codigo="0442" />
    <ItineraryRow via="Beco Sem Nome" match="nao_encontrado" />
  </ul>
</SidebarPanel>

<SidebarPanel title="Horários" hint="Selecione uma linha para ver o quadro." />
```

- **Route colors are functional**: IDA green (`--ida`), VOLTA blue (`--volta`) — the same colors drawn on the map. Do not recolor them to gold.
- **MatchMark**/**ItineraryRow** `match` values come straight from the ETL matcher (`exato`, `fuzzy`, `nao_encontrado`, …).
- **SidebarPanel** is the wrapper for every map-sidebar section (Estilo do Mapa, Horários, Itinerário, Buscar por rua).
