// DashboardsScreen — GEPOT Power BI dashboards grid. Público vs Interno via Badge tone.
const DSb = window.DMTTMaceiDesignSystem_aa209f;

const DASHBOARDS = [
  { titulo: "Frota e Quilometragem", descricao: "Acompanhamento mensal de quilometragem rodada por linha e por motorista.", tipo: "interno" },
  { titulo: "Itinerários e Pontos de Parada", descricao: "Visão consolidada de linhas, ruas atendidas e pontos de parada por bairro.", tipo: "publico" },
  { titulo: "Indicadores Mensais GEPOT", descricao: "Painel de indicadores do setor: relatórios entregues, prazos e pendências.", tipo: "interno" },
  { titulo: "Reclamações por Bairro", descricao: "Mapa de calor das reclamações recebidas, cruzado com linhas que atendem cada bairro.", tipo: "publico" },
];

function DashboardsScreen() {
  return (
    <div style={{ flex: 1, minHeight: 0, overflowY: "auto", padding: "32px 36px 56px" }}>
      <div style={{ maxWidth: 900 }}>
        <h1 style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 26, color: "var(--text-1)", marginBottom: 6 }}>Dashboards — GEPOT</h1>
        <p style={{ fontSize: 14, color: "var(--text-subtle)", marginBottom: 28, maxWidth: 620, lineHeight: 1.55 }}>
          Relatórios e indicadores do setor, publicados no Power BI. Atualização manual — a raspagem pesada roda sexta, o <code style={{ fontFamily: "var(--font-mono)", fontSize: 12, color: "var(--gold-700)" }}>.pbix</code> é republicado segunda. Os links abaixo não mudam, só o conteúdo por trás.
        </p>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 16 }}>
          {DASHBOARDS.map((d) => (
            <DSb.Card key={d.titulo} interactive as="a" href="#">
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
                <span style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 16, color: "var(--text-1)" }}>{d.titulo}</span>
                <DSb.Badge tone={d.tipo === "publico" ? "success" : "warning"}>{d.tipo === "publico" ? "Público" : "Interno"}</DSb.Badge>
              </div>
              <p style={{ fontSize: 13, color: "var(--text-subtle)", lineHeight: 1.5, flex: 1, margin: 0 }}>{d.descricao}</p>
              <span style={{ fontSize: 13, fontWeight: 600, color: "var(--gold-700)" }}>Abrir dashboard →</span>
            </DSb.Card>
          ))}
        </div>
      </div>
    </div>
  );
}
window.DashboardsScreen = DashboardsScreen;
