// LinhasScreen — the core product view: line selector + dark map + sidebar
// (map style, horários, itinerário, busca por rua). Composes the DS primitives.
const DS = window.DMTTMaceiDesignSystem_aa209f;
const { MultiSelect, Select, SidebarPanel, Tabs, TimeChip, RouteBadge, ItineraryRow, OptionButton, Button } = DS;

const LINHAS = [
  { id: "1", label: "001 — Centro / Benedito Bentes" },
  { id: "2", label: "012 — Jacintinho / Ponta Verde" },
  { id: "3", label: "023 — Cidade Universitária / Farol" },
  { id: "4", label: "047 — Tabuleiro / Centro" },
  { id: "5", label: "052 — Serraria / Jatiúca" },
  { id: "6", label: "710 — Trapiche / Pajuçara" },
];

const ITINERARIO = {
  nome: "012 — Jacintinho / Ponta Verde",
  ida: [
    { via: "Terminal do Jacintinho", match: "exato", codigo: "9001" },
    { via: "Av. Menino Marcelo", match: "exato", codigo: "1023" },
    { via: "Av. Fernandes Lima", match: "exato", codigo: "1104" },
    { via: "Rua Barão de Anadia", match: "fuzzy", codigo: "0442" },
    { via: "Av. Álvaro Otacílio (Orla)", match: "exato", codigo: "1330" },
  ],
  volta: [
    { via: "Av. Álvaro Otacílio (Orla)", match: "exato", codigo: "1330" },
    { via: "Rua Jangadeiros Alagoanos", match: "nao_encontrado" },
    { via: "Av. Fernandes Lima", match: "exato", codigo: "1104" },
    { via: "Terminal do Jacintinho", match: "exato", codigo: "9001" },
  ],
};

const HORARIOS = {
  dia_util: { ida: ["05:10", "05:38", "06:04", "06:30", "06:58", "07:24", "07:50"], volta: ["05:45", "06:15", "06:48", "07:20", "07:55"] },
  sabado: { ida: ["05:30", "06:20", "07:10", "08:00"], volta: ["06:00", "07:00", "08:00"] },
  domingo: { ida: ["06:00", "07:30", "09:00"], volta: ["06:45", "08:15"] },
};

const MAP_STYLES = [
  { key: "claro", label: "Claro", sw: "#F2F4F7" },
  { key: "streets", label: "Ruas", sw: "#E4E7EC" },
  { key: "sat", label: "Satélite", sw: "#6E7B55" },
];

function LinhasScreen() {
  const [sel, setSel] = React.useState(["2"]);
  const [sentido, setSentido] = React.useState("ambos");
  const [mapStyle, setMapStyle] = React.useState("claro");
  const [terminais, setTerminais] = React.useState(true);
  const [dia, setDia] = React.useState("dia_util");
  const [rua, setRua] = React.useState("");
  const [contexto, setContexto] = React.useState(null);

  const single = sel.length === 1;
  const dh = HORARIOS[dia];

  function toggle(id) {
    setSel((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));
    setContexto(null);
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", minHeight: 0 }}>
      {/* controls bar */}
      <div style={{ display: "flex", alignItems: "center", gap: 16, padding: "10px 16px", background: "var(--surface-base)", borderBottom: "1px solid var(--border-2)", flexShrink: 0, flexWrap: "wrap" }}>
        <label style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ fontSize: 12, fontWeight: 600, color: "var(--text-subtle)" }}>Linhas</span>
          <MultiSelect options={LINHAS} selectedIds={sel} onToggle={toggle} onClear={() => { setSel([]); setContexto(null); }} panelWidth={360} />
        </label>
        <Select label="Sentido" value={sentido} onChange={(e) => setSentido(e.target.value)}>
          <option value="ambos">Ida e Volta</option>
          <option value="ida">Somente Ida</option>
          <option value="volta">Somente Volta</option>
        </Select>
      </div>

      {/* body: map + sidebar */}
      <div style={{ display: "flex", flex: 1, minHeight: 0, overflow: "hidden" }}>
        <div style={{ flex: 1, position: "relative", minWidth: 0 }}>
          <MapCanvas
            sentido={sentido} showTerminais={terminais} contexto={contexto}
            onClickPoint={() => { setRua("Av. Fernandes Lima"); setContexto({ linha: "012 — Jacintinho", sentido: "IDA", rua: "Av. Fernandes Lima" }); }}
          />
        </div>

        <aside style={{ width: 340, flexShrink: 0, display: "flex", flexDirection: "column", background: "var(--surface-base)", borderLeft: "1px solid var(--border-2)", overflowY: "auto" }}>
          {/* map style + terminais */}
          <SidebarPanel title="Estilo do mapa">
            <div style={{ display: "flex", flexDirection: "column", gap: 4, padding: "8px 16px 12px" }}>
              {MAP_STYLES.map((m) => (
                <OptionButton key={m.key} active={mapStyle === m.key} onClick={() => setMapStyle(m.key)}
                  swatch={<span style={{ width: 24, height: 24, borderRadius: 4, background: m.sw, border: "1px solid rgba(255,255,255,.15)" }} />}>{m.label}</OptionButton>
              ))}
              <OptionButton active={terminais} accent="#F0A73B" accentSoft="rgba(240,167,59,.14)" onClick={() => setTerminais((v) => !v)}
                swatch={<span style={{ width: 24, height: 24, borderRadius: "50%", background: "#F0A73B", border: "2px solid #0C0D10", boxShadow: "0 0 0 1px rgba(255,255,255,.15)" }} />}>Terminais</OptionButton>
            </div>
          </SidebarPanel>

          {/* horários (only when 1 line) */}
          {single && (
            <SidebarPanel title="Horários">
              <div style={{ padding: "8px 16px 4px" }}>
                <Tabs value={dia} onChange={setDia} items={[
                  { key: "dia_util", label: "Dia Útil" }, { key: "sabado", label: "Sábado" }, { key: "domingo", label: "Domingo" },
                ]} />
                <div style={{ border: "1px solid var(--border-2)", borderTop: "none", borderRadius: "0 0 var(--radius) var(--radius)", padding: "10px 12px", display: "flex", flexDirection: "column", gap: 10, marginBottom: 12 }}>
                  <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                    <span style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.05em", color: "var(--ida)" }}>→ IDA</span>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>{dh.ida.map((h) => <TimeChip key={h}>{h}</TimeChip>)}</div>
                  </div>
                  <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                    <span style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.05em", color: "var(--volta)" }}>← VOLTA</span>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>{dh.volta.map((h) => <TimeChip key={h}>{h}</TimeChip>)}</div>
                  </div>
                </div>
              </div>
            </SidebarPanel>
          )}

          {/* itinerário */}
          <SidebarPanel title="Itinerário" hint={single ? null : "Selecione uma única linha para ver o itinerário."}>
            {single && (
              <div>
                <p style={{ padding: "8px 16px", fontSize: 12, fontWeight: 600, color: "var(--text-subtle)", background: "var(--ink-800)" }}>{ITINERARIO.nome}</p>
                {sentido !== "volta" && (
                  <div>
                    <h3 style={{ fontSize: 12, fontWeight: 700, padding: "8px 16px", borderLeft: "3px solid var(--ida)", color: "var(--text-subtle)", background: "var(--ink-800)" }}>→ IDA</h3>
                    <ul style={{ margin: 0, padding: 0 }}>{ITINERARIO.ida.map((r, i) => <ItineraryRow key={i} {...r} />)}</ul>
                  </div>
                )}
                {sentido !== "ida" && (
                  <div>
                    <h3 style={{ fontSize: 12, fontWeight: 700, padding: "8px 16px", borderLeft: "3px solid var(--volta)", color: "var(--text-subtle)", background: "var(--ink-800)" }}>← VOLTA</h3>
                    <ul style={{ margin: 0, padding: 0 }}>{ITINERARIO.volta.map((r, i) => <ItineraryRow key={i} {...r} />)}</ul>
                  </div>
                )}
              </div>
            )}
          </SidebarPanel>

          {/* busca por rua */}
          <SidebarPanel title="Buscar por rua" divider={false}>
            <div style={{ padding: "10px 16px 16px" }}>
              <DS.SearchInput icon={<span>⌕</span>} placeholder="Ex.: Fernandes Lima" value={rua} onChange={(e) => setRua(e.target.value)} />
              <p style={{ fontSize: 11, color: "var(--text-hint)", margin: "6px 0 0" }}>Dica: clique em qualquer ponto do mapa para descobrir a rua.</p>

              {rua.toLowerCase().includes("fernandes") && (
                <div style={{ marginTop: 12 }}>
                  <p style={{ fontSize: 12, color: "var(--text-hint)", marginBottom: 8 }}>2 linha(s) em "Fernandes Lima"</p>
                  {[{ n: "012 — Jacintinho / Ponta Verde", s: [["ida", "1104"], ["volta", "1104"]] }, { n: "023 — Cidade Universitária", s: [["ida", "2210"]] }].map((l, i) => (
                    <div key={i} style={{ padding: "8px 0", borderBottom: "1px solid var(--border-1)" }}>
                      <button style={{ background: "none", border: "none", padding: 0, fontSize: 13, fontWeight: 600, color: "var(--gold-700)", cursor: "pointer", marginBottom: 6, display: "block" }}
                        onClick={() => { setSel(["2"]); setContexto(null); }}>{l.n}</button>
                      <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
                        {l.s.map(([sent, code], j) => <RouteBadge key={j} sentido={sent} code={code} onClick={() => setContexto({ linha: l.n, sentido: sent.toUpperCase(), rua: "Av. Fernandes Lima" })} />)}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </SidebarPanel>
        </aside>
      </div>
    </div>
  );
}
window.LinhasScreen = LinhasScreen;
