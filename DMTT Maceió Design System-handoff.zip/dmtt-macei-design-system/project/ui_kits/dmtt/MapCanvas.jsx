// MapCanvas — stylized LIGHT map stand-in for the Leaflet/OSM view.
// The real product renders OpenStreetMap tiles with route polylines; here we
// evoke that with a light SVG basemap, IDA/VOLTA route lines, terminais, legend,
// and the contextual street callout.
const { useMemo } = React;

function MapCanvas({ sentido = "ambos", showTerminais = false, contexto = null, onClickPoint }) {
  // faint pseudo-street grid
  const grid = useMemo(() => {
    const lines = [];
    for (let x = 40; x < 900; x += 64) lines.push({ x1: x, y1: 0, x2: x + 90, y2: 620 });
    for (let y = 30; y < 620; y += 58) lines.push({ x1: 0, y1: y, x2: 900, y2: y - 40 });
    return lines;
  }, []);

  const ida = "M 70 540 C 200 500, 250 380, 380 360 S 560 300, 660 200 S 790 120, 840 70";
  const volta = "M 840 96 C 780 150, 640 230, 560 300 S 360 380, 300 430 S 150 540, 80 560";

  return (
    <div
      onClick={(e) => {
        const r = e.currentTarget.getBoundingClientRect();
        onClickPoint && onClickPoint(e.clientX - r.left, e.clientY - r.top);
      }}
      style={{
        position: "absolute", inset: 0, overflow: "hidden", cursor: "crosshair",
        background: "radial-gradient(120% 90% at 30% 20%, #F3F5F8 0%, #E9ECF1 60%, #E2E6EC 100%)",
      }}
    >
      <svg viewBox="0 0 900 620" preserveAspectRatio="xMidYMid slice" style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
        {/* park / green block */}
        <path d="M 120 40 Q 260 30 300 120 T 240 250 Q 120 240 100 140 Z" fill="#E2ECDD" opacity="0.9" />
        {/* water */}
        <path d="M 0 470 C 200 440, 380 500, 560 470 S 900 420, 900 470 L 900 620 L 0 620 Z" fill="#D3E3EE" opacity="0.95" />
        {/* street grid */}
        <g stroke="#DEE2E8" strokeWidth="1.5">
          {grid.map((l, i) => <line key={i} x1={l.x1} y1={l.y1} x2={l.x2} y2={l.y2} />)}
        </g>
        <g stroke="#CBD0D8" strokeWidth="3.5" opacity="0.9">
          <line x1="0" y1="250" x2="900" y2="200" />
          <line x1="120" y1="0" x2="220" y2="620" />
          <line x1="560" y1="0" x2="600" y2="620" />
        </g>
        {/* routes */}
        {sentido !== "volta" && (
          <path d={ida} fill="none" stroke="#16A34A" strokeWidth="5" strokeLinecap="round"
            style={{ filter: "drop-shadow(0 1px 2px rgba(22,163,74,0.35))" }} />
        )}
        {sentido !== "ida" && (
          <path d={volta} fill="none" stroke="#2E64D4" strokeWidth="5" strokeLinecap="round"
            style={{ filter: "drop-shadow(0 1px 2px rgba(46,100,212,0.35))" }} />
        )}
        {/* terminais */}
        {showTerminais && [[70, 540], [840, 70], [380, 360]].map(([cx, cy], i) => (
          <g key={i}>
            <circle cx={cx} cy={cy} r="9" fill="#D98407" stroke="#FFFFFF" strokeWidth="3"
              style={{ filter: "drop-shadow(0 1px 2px rgba(18,24,40,0.25))" }} />
          </g>
        ))}
      </svg>

      {/* legend */}
      <div style={{
        position: "absolute", bottom: 20, left: 14, display: "flex", gap: 12,
        background: "rgba(255,255,255,0.92)", border: "1px solid var(--border-2)",
        borderRadius: "var(--radius)", padding: "6px 12px", fontSize: 12, fontWeight: 600,
        color: "var(--text-2)", backdropFilter: "blur(4px)", boxShadow: "var(--shadow-sm)",
      }}>
        <span style={{ display: "flex", alignItems: "center", gap: 5 }}><i style={{ width: 18, height: 4, borderRadius: 2, background: "#16A34A" }} />IDA</span>
        <span style={{ display: "flex", alignItems: "center", gap: 5 }}><i style={{ width: 18, height: 4, borderRadius: 2, background: "#2E64D4" }} />VOLTA</span>
        <span style={{ display: "flex", alignItems: "center", gap: 5 }}><i style={{ width: 18, height: 4, borderRadius: 2, background: "#E0A400" }} />Rua</span>
      </div>

      {/* attribution */}
      <div style={{ position: "absolute", bottom: 4, right: 8, fontSize: 10, color: "var(--text-4)" }}>© OpenStreetMap</div>

      {/* contextual callout */}
      {contexto && (
        <div style={{
          position: "absolute", bottom: 60, right: 14, width: 250, padding: "11px 13px",
          background: "#FFFFFF", borderLeft: "3px solid var(--gold-400)", borderRadius: 6,
          boxShadow: "var(--shadow-lg)", fontSize: 12, color: "var(--text-2)",
        }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "var(--gold-700)", textTransform: "uppercase", letterSpacing: "0.04em", marginBottom: 5 }}>Rua identificada</div>
          <div style={{ lineHeight: 1.5, marginBottom: 8 }}>
            Mostrando <strong style={{ color: "var(--text-1)" }}>{contexto.linha}</strong> no sentido <em style={{ fontStyle: "normal", color: "var(--warning-text)", fontWeight: 700 }}>{contexto.sentido}</em> que passa em <strong style={{ color: "var(--text-1)" }}>{contexto.rua}</strong>.
          </div>
        </div>
      )}
    </div>
  );
}
window.MapCanvas = MapCanvas;
