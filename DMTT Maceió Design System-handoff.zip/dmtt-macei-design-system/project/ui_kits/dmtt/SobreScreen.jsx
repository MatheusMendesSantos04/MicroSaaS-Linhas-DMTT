// SobreScreen — "about" prose page.
function SobreScreen() {
  const H = ({ children }) => <h2 style={{ fontFamily: "var(--font-display)", fontWeight: 600, fontSize: 19, color: "var(--text-1)", margin: "26px 0 8px" }}>{children}</h2>;
  const P = ({ children }) => <p style={{ fontSize: 14, color: "var(--text-subtle)", lineHeight: 1.65, marginBottom: 8, maxWidth: 620 }}>{children}</p>;
  const S = ({ children }) => <strong style={{ color: "var(--text-1)", fontWeight: 700 }}>{children}</strong>;
  return (
    <div style={{ flex: 1, minHeight: 0, overflowY: "auto", padding: "32px 36px 56px" }}>
      <div style={{ maxWidth: 900 }}>
        <h1 style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 26, color: "var(--text-1)", marginBottom: 10 }}>Sobre o sistema</h1>
        <P>O <S>Linhas DMTT</S> é um sistema da DMTT (Diretoria de Mobilidade e Trânsito de Maceió/AL) para consulta de itinerários de ônibus, criado pelo setor GEPOT.</P>
        <H>O que ele resolve</H>
        <P>Quando o setor recebe uma reclamação sobre um ônibus, é preciso descobrir qual linha passava por determinada rua em determinado horário. Este sistema permite:</P>
        <ul style={{ fontSize: 14, color: "var(--text-subtle)", lineHeight: 1.8, paddingLeft: 20, maxWidth: 620 }}>
          <li>Visualizar o traçado de qualquer linha no mapa, com os sentidos IDA e VOLTA.</li>
          <li>Ver o itinerário completo (ruas atendidas) e o quadro de horários por linha.</li>
          <li>Buscar por nome de rua e listar todas as linhas que passam ali.</li>
          <li>Filtrar essa busca por horário (janela de ±20 min) para identificar o ônibus provável.</li>
          <li>Clicar em qualquer ponto do mapa para descobrir automaticamente a rua e as linhas que a atendem.</li>
        </ul>
        <H>Dashboards</H>
        <P>A seção <S>Dashboards</S> reúne os relatórios e indicadores do GEPOT publicados no Power BI, centralizando o acesso num único lugar.</P>
        <H>Como os dados funcionam</H>
        <P>O sistema é totalmente estático — sem servidor rodando em produção. Os dados de linhas, itinerários e horários são gerados a partir da base oficial do setor e publicados junto com o site.</P>
      </div>
    </div>
  );
}
window.SobreScreen = SobreScreen;
